import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";

const GameApp = lazy(() => import("@/game/GameApp"));

export const Route = createFileRoute("/")({ component: Home });

function Shell() {
  return (
    <main className="flex h-[100dvh] items-end justify-center bg-bg text-fg sm:items-center">
      <div className="mb-10 w-[min(28rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 sm:mb-0">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">
          Quartier libre
        </p>
        <h1 className="font-display mt-2 text-4xl tracking-tight">ASHWOOD</h1>
        <p className="mt-3 text-sm text-muted">Chargement du quartier…</p>
      </div>
    </main>
  );
}

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) return <Shell />;
  return (
    <Suspense fallback={<Shell />}>
      <GameApp />
    </Suspense>
  );
}

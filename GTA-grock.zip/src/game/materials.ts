import * as THREE from "three";

function hash(ix: number, iy: number): number {
  const n = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453;
  return n - Math.floor(n);
}

function noise(x: number, y: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash(ix, iy);
  const b = hash(ix + 1, iy);
  const c = hash(ix, iy + 1);
  const d = hash(ix + 1, iy + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}

function fbm(x: number, y: number): number {
  return (
    noise(x, y) * 0.55 + noise(x * 2.1, y * 2.1) * 0.28 + noise(x * 4.3, y * 4.3) * 0.17
  );
}

function canvasTex(
  size: number,
  paint: (ctx: CanvasRenderingContext2D, size: number) => void,
  repeat = 1,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d")!;
  paint(ctx, size);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

function asphalt(ctx: CanvasRenderingContext2D, s: number) {
  const img = ctx.createImageData(s, s);
  const d = img.data;
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const n = fbm(x * 0.07, y * 0.07);
      const crack = noise(x * 0.35, y * 0.04);
      let v = 38 + n * 28;
      if (crack > 0.78) v -= 16;
      const i = (y * s + x) * 4;
      d[i] = v;
      d[i + 1] = v * 0.98;
      d[i + 2] = v * 0.92;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.strokeStyle = "rgba(210, 170, 40, 0.72)";
  ctx.lineWidth = 4;
  ctx.setLineDash([18, 16]);
  ctx.beginPath();
  ctx.moveTo(s * 0.5, 0);
  ctx.lineTo(s * 0.5, s);
  ctx.stroke();
}

function concrete(ctx: CanvasRenderingContext2D, s: number) {
  const img = ctx.createImageData(s, s);
  const d = img.data;
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const n = fbm(x * 0.08, y * 0.08);
      const v = 148 + n * 22;
      const i = (y * s + x) * 4;
      d[i] = v;
      d[i + 1] = v - 4;
      d[i + 2] = v - 10;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.strokeStyle = "rgba(90, 90, 86, 0.28)";
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, s - 2, s - 2);
}

function grass(ctx: CanvasRenderingContext2D, s: number) {
  const img = ctx.createImageData(s, s);
  const d = img.data;
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const n = fbm(x * 0.09, y * 0.09);
      const p = noise(x * 0.4, y * 0.4);
      const i = (y * s + x) * 4;
      d[i] = 62 + n * 40 + p * 12;
      d[i + 1] = 88 + n * 50;
      d[i + 2] = 42 + n * 18;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}

function stucco(r: number, g: number, b: number) {
  return (ctx: CanvasRenderingContext2D, s: number) => {
    const img = ctx.createImageData(s, s);
    const d = img.data;
    for (let y = 0; y < s; y++) {
      for (let x = 0; x < s; x++) {
        const n = fbm(x * 0.12, y * 0.12);
        const i = (y * s + x) * 4;
        d[i] = r + n * 22;
        d[i + 1] = g + n * 18;
        d[i + 2] = b + n * 14;
        d[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  };
}

function roof(ctx: CanvasRenderingContext2D, s: number) {
  ctx.fillStyle = "#6b3a32";
  ctx.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y += 10) {
    const odd = ((y / 10) | 0) % 2;
    for (let x = -8; x < s; x += 16) {
      ctx.fillStyle = odd ? "#7a4438" : "#5e322c";
      ctx.fillRect(x, y, 15, 9);
      ctx.strokeStyle = "rgba(40,18,14,0.35)";
      ctx.strokeRect(x, y, 15, 9);
    }
  }
}

function wood(ctx: CanvasRenderingContext2D, s: number) {
  const img = ctx.createImageData(s, s);
  const d = img.data;
  for (let y = 0; y < s; y++) {
    for (let x = 0; x < s; x++) {
      const n = fbm(x * 0.02, y * 0.18);
      const plank = Math.floor(x / 18);
      const i = (y * s + x) * 4;
      d[i] = 118 + n * 30 + (plank % 2) * 8;
      d[i + 1] = 86 + n * 22;
      d[i + 2] = 54 + n * 14;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  ctx.strokeStyle = "rgba(50,30,18,0.35)";
  for (let x = 18; x < s; x += 18) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, s);
    ctx.stroke();
  }
}

function brick(ctx: CanvasRenderingContext2D, s: number) {
  ctx.fillStyle = "#4a302c";
  ctx.fillRect(0, 0, s, s);
  const bh = 12;
  const bw = 24;
  for (let y = 0, row = 0; y < s; y += bh, row++) {
    const off = row % 2 ? bw * 0.5 : 0;
    for (let x = -bw; x < s; x += bw) {
      const n = hash(x, y);
      ctx.fillStyle = `rgb(${110 + n * 30 | 0},${62 + n * 16 | 0},${48 + n * 10 | 0})`;
      ctx.fillRect(x + off + 1, y + 1, bw - 2, bh - 2);
    }
  }
}

export type Mats = {
  asphalt: THREE.MeshStandardMaterial;
  sidewalk: THREE.MeshStandardMaterial;
  grass: THREE.MeshStandardMaterial;
  stuccoCream: THREE.MeshStandardMaterial;
  stuccoTeal: THREE.MeshStandardMaterial;
  stuccoSand: THREE.MeshStandardMaterial;
  stuccoInside: THREE.MeshStandardMaterial;
  roof: THREE.MeshStandardMaterial;
  wood: THREE.MeshStandardMaterial;
  brick: THREE.MeshStandardMaterial;
  metal: THREE.MeshStandardMaterial;
  glass: THREE.MeshStandardMaterial;
  foliage: THREE.MeshStandardMaterial;
  trunk: THREE.MeshStandardMaterial;
  trim: THREE.MeshStandardMaterial;
};

let cache: Mats | null = null;

function std(
  map: THREE.Texture | null,
  color: string,
  extra?: Partial<THREE.MeshStandardMaterialParameters>,
): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    map: map ?? undefined,
    color,
    roughness: 0.86,
    metalness: 0.04,
    ...extra,
  });
}

export function getMaterials(): Mats {
  if (cache) return cache;
  const asphaltMap = canvasTex(256, asphalt, 1);
  asphaltMap.repeat.set(1, 6);
  const conc = canvasTex(256, concrete, 4);
  const gr = canvasTex(256, grass, 10);
  const cream = canvasTex(256, stucco(196, 176, 148), 3);
  const teal = canvasTex(256, stucco(78, 122, 118), 3);
  const sand = canvasTex(256, stucco(186, 154, 108), 3);
  const inside = canvasTex(256, stucco(214, 204, 186), 2);
  const rf = canvasTex(256, roof, 4);
  const wd = canvasTex(256, wood, 2);
  const br = canvasTex(256, brick, 3);
  cache = {
    asphalt: std(asphaltMap, "#8a8a88", { roughness: 0.92 }),
    sidewalk: std(conc, "#c4c0b6", { roughness: 0.9 }),
    grass: std(gr, "#7a9a5c", { roughness: 0.95, side: THREE.DoubleSide }),
    stuccoCream: std(cream, "#ffffff"),
    stuccoTeal: std(teal, "#d5e0dc"),
    stuccoSand: std(sand, "#ffffff"),
    stuccoInside: std(inside, "#ffffff", { roughness: 0.8 }),
    roof: std(rf, "#ffffff", { roughness: 0.78 }),
    wood: std(wd, "#ffffff", { roughness: 0.72 }),
    brick: std(br, "#ffffff", { roughness: 0.88 }),
    metal: std(null, "#4c4c4c", { roughness: 0.45, metalness: 0.55 }),
    glass: std(null, "#1c2830", {
      roughness: 0.18,
      metalness: 0.35,
      transparent: true,
      opacity: 0.55,
    }),
    foliage: std(null, "#3f6b3a", { roughness: 0.95 }),
    trunk: std(null, "#5a3d2a", { roughness: 0.9 }),
    trim: std(null, "#ece3d2", { roughness: 0.7 }),
  };
  return cache;
}

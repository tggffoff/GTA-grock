import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Group } from "three";
import { sim } from "./sim";

function Wheel({
  position,
  steer = false,
}: {
  position: [number, number, number];
  steer?: boolean;
}) {
  const ref = useRef<Group>(null);
  useFrame(() => {
    const g = ref.current;
    if (!g) return;
    g.rotation.y = steer ? sim.steerVis * 0.42 : 0;
    const rim = g.children[0] as Group | undefined;
    if (rim) rim.rotation.x = sim.wheel;
  });
  return (
    <group ref={ref} position={position}>
      <group>
        <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.28, 0.28, 0.18, 12]} />
          <meshStandardMaterial color="#1a1a1a" roughness={0.8} />
        </mesh>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.16, 0.16, 0.2, 10]} />
          <meshStandardMaterial color="#b0aaa2" metalness={0.45} roughness={0.4} />
        </mesh>
      </group>
    </group>
  );
}

export function CarMesh() {
  const ref = useRef<Group>(null);
  useFrame(() => {
    const g = ref.current;
    if (!g) return;
    g.position.set(sim.cx, 0, sim.cz);
    g.rotation.set(0, sim.cyaw, 0);
  });

  const body = "#c9b79a";
  const lower = "#8a3e32";
  const cabin = "#2a3640";

  return (
    <group ref={ref}>
      <mesh position={[0, 0.38, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.48, 0.42, 3.22]} />
        <meshStandardMaterial color={lower} roughness={0.55} metalness={0.12} />
      </mesh>
      <mesh position={[0, 0.62, 0.08]} castShadow>
        <boxGeometry args={[1.42, 0.22, 3.05]} />
        <meshStandardMaterial color={body} roughness={0.48} metalness={0.15} />
      </mesh>
      <mesh position={[0, 1.02, -0.12]} castShadow>
        <boxGeometry args={[1.28, 0.55, 1.55]} />
        <meshStandardMaterial color={body} roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.05, -0.08]}>
        <boxGeometry args={[1.18, 0.42, 1.35]} />
        <meshStandardMaterial color={cabin} roughness={0.2} metalness={0.25} />
      </mesh>
      <mesh position={[0, 1.32, -0.12]}>
        <boxGeometry args={[1.3, 0.06, 1.62]} />
        <meshStandardMaterial color="#6a5a4a" roughness={0.7} />
      </mesh>
      <mesh position={[0.52, 0.48, -1.52]}>
        <boxGeometry args={[0.28, 0.16, 0.08]} />
        <meshStandardMaterial color="#f2e6c0" emissive="#f0e0a8" emissiveIntensity={0.4} />
      </mesh>
      <mesh position={[-0.52, 0.48, -1.52]}>
        <boxGeometry args={[0.28, 0.16, 0.08]} />
        <meshStandardMaterial color="#f2e6c0" emissive="#f0e0a8" emissiveIntensity={0.4} />
      </mesh>
      <mesh position={[0.5, 0.48, 1.58]}>
        <boxGeometry args={[0.32, 0.14, 0.06]} />
        <meshStandardMaterial color="#8a1e18" emissive="#5a0c08" emissiveIntensity={0.35} />
      </mesh>
      <mesh position={[-0.5, 0.48, 1.58]}>
        <boxGeometry args={[0.32, 0.14, 0.06]} />
        <meshStandardMaterial color="#8a1e18" emissive="#5a0c08" emissiveIntensity={0.35} />
      </mesh>
      <mesh position={[0, 0.42, -1.55]}>
        <boxGeometry args={[0.85, 0.12, 0.06]} />
        <meshStandardMaterial color="#2a2a2a" />
      </mesh>
      <mesh position={[0.74, 0.7, 0.15]}>
        <boxGeometry args={[0.04, 0.28, 1.1]} />
        <meshStandardMaterial color="#1c1c1c" />
      </mesh>
      <mesh position={[-0.74, 0.7, 0.15]}>
        <boxGeometry args={[0.04, 0.28, 1.1]} />
        <meshStandardMaterial color="#1c1c1c" />
      </mesh>
      <Wheel position={[0.62, 0.28, -0.95]} steer />
      <Wheel position={[-0.62, 0.28, -0.95]} steer />
      <Wheel position={[0.62, 0.28, 1.05]} />
      <Wheel position={[-0.62, 0.28, 1.05]} />
    </group>
  );
}

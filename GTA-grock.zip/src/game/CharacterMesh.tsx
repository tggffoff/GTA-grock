import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Group } from "three";
import { sim } from "./sim";
import { PLAYER_HALF_H } from "./constants";

export function CharacterMesh() {
  const ref = useRef<Group>(null);
  const lLeg = useRef<Group>(null);
  const rLeg = useRef<Group>(null);
  const lArm = useRef<Group>(null);
  const rArm = useRef<Group>(null);
  const torso = useRef<Group>(null);

  useFrame(() => {
    const g = ref.current;
    if (!g) return;
    g.visible = sim.visiblePlayer;
    g.position.set(sim.px, sim.py - PLAYER_HALF_H, sim.pz);
    g.rotation.set(0, sim.yaw + Math.PI, 0);
    const moving = Math.hypot(sim.pvx, sim.pvz) > 0.35 && !sim.inVehicle;
    const swing = moving ? Math.sin(sim.walkPhase) * 0.55 : 0;
    const bob = moving ? Math.abs(Math.sin(sim.walkPhase)) * 0.035 : 0;
    if (lLeg.current) lLeg.current.rotation.x = swing;
    if (rLeg.current) rLeg.current.rotation.x = -swing;
    if (lArm.current) lArm.current.rotation.x = -swing * 0.7;
    if (rArm.current) rArm.current.rotation.x = swing * 0.7;
    if (torso.current) torso.current.position.y = 0.92 + bob;
  });

  const skin = "#c4a07a";
  const shirt = "#6b6a4a";
  const pants = "#3d4a62";
  const shoe = "#2a2a28";
  const hair = "#2b241c";

  return (
    <group ref={ref} castShadow>
      <group ref={torso} position={[0, 0.92, 0]}>
        <mesh position={[0, 0.18, 0]} castShadow>
          <boxGeometry args={[0.42, 0.52, 0.26]} />
          <meshStandardMaterial color={shirt} roughness={0.82} />
        </mesh>
        <mesh position={[0, -0.16, 0]} castShadow>
          <boxGeometry args={[0.4, 0.22, 0.24]} />
          <meshStandardMaterial color="#5a5940" roughness={0.85} />
        </mesh>
        <mesh position={[0, 0.52, 0.02]} castShadow>
          <sphereGeometry args={[0.155, 10, 8]} />
          <meshStandardMaterial color={skin} roughness={0.7} />
        </mesh>
        <mesh position={[0, 0.6, -0.01]} castShadow>
          <sphereGeometry args={[0.16, 10, 8]} />
          <meshStandardMaterial color={hair} roughness={0.9} />
        </mesh>
        <mesh position={[0.09, 0.54, 0.13]}>
          <boxGeometry args={[0.05, 0.03, 0.02]} />
          <meshStandardMaterial color="#1c1a16" />
        </mesh>
        <mesh position={[-0.09, 0.54, 0.13]}>
          <boxGeometry args={[0.05, 0.03, 0.02]} />
          <meshStandardMaterial color="#1c1a16" />
        </mesh>
        <group ref={lArm} position={[0.28, 0.16, 0]}>
          <mesh position={[0, -0.2, 0]} castShadow>
            <boxGeometry args={[0.1, 0.46, 0.1]} />
            <meshStandardMaterial color={skin} roughness={0.72} />
          </mesh>
          <mesh position={[0, 0.05, 0]}>
            <boxGeometry args={[0.12, 0.2, 0.13]} />
            <meshStandardMaterial color={shirt} />
          </mesh>
        </group>
        <group ref={rArm} position={[-0.28, 0.16, 0]}>
          <mesh position={[0, -0.2, 0]} castShadow>
            <boxGeometry args={[0.1, 0.46, 0.1]} />
            <meshStandardMaterial color={skin} roughness={0.72} />
          </mesh>
          <mesh position={[0, 0.05, 0]}>
            <boxGeometry args={[0.12, 0.2, 0.13]} />
            <meshStandardMaterial color={shirt} />
          </mesh>
        </group>
      </group>
      <group ref={lLeg} position={[0.11, 0.52, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <boxGeometry args={[0.14, 0.52, 0.16]} />
          <meshStandardMaterial color={pants} roughness={0.85} />
        </mesh>
        <mesh position={[0, -0.56, 0.04]} castShadow>
          <boxGeometry args={[0.15, 0.1, 0.24]} />
          <meshStandardMaterial color={shoe} />
        </mesh>
      </group>
      <group ref={rLeg} position={[-0.11, 0.52, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <boxGeometry args={[0.14, 0.52, 0.16]} />
          <meshStandardMaterial color={pants} roughness={0.85} />
        </mesh>
        <mesh position={[0, -0.56, 0.04]} castShadow>
          <boxGeometry args={[0.15, 0.1, 0.24]} />
          <meshStandardMaterial color={shoe} />
        </mesh>
      </group>
    </group>
  );
}

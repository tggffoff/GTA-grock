import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { TouchControls } from "./TouchControls";
import { useHud } from "./hudState";
import { sim } from "./sim";

export function Overlay() {
  const hud = useHud();
  const [coarse, setCoarse] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse)");
    setCoarse(mq.matches);
    const fn = () => setCoarse(mq.matches);
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 text-fg">
      {!hud.started && (
        <div className="pointer-events-auto absolute inset-0 flex items-end justify-center bg-bg/55 sm:items-center">
          <div className="mb-[max(2rem,env(safe-area-inset-bottom))] w-[min(28rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 sm:mb-0">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">
              Quartier libre
            </p>
            <h1 className="font-display mt-2 text-4xl tracking-tight text-fg sm:text-5xl">
              ASHWOOD
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Un pâté de maisons à explorer à pied ou en voiture. Entre dans la
              maison, ouvre la porte, monte dans le Veldora.
            </p>
            <ul className="mt-5 space-y-1.5 text-sm text-muted">
              <li>ZQSD / WASD — marcher ou conduire</li>
              <li>Souris / glisser — caméra</li>
              <li>Maj — courir · E — interagir</li>
            </ul>
            <Button
              className="mt-6 w-full"
              size="lg"
              data-testid="start-game"
              onClick={() => sim.enterPlayer()}
            >
              Jouer
            </Button>
          </div>
        </div>
      )}

      {hud.started && !hud.paused && (
        <>
          <div className="absolute left-[max(1rem,env(safe-area-inset-left))] top-[max(1rem,env(safe-area-inset-top))] rounded-md border border-border bg-surface/70 px-3 py-2">
            <p className="font-display text-sm tracking-wide">ASHWOOD</p>
            {hud.inVehicle && (
              <p className="mt-0.5 font-mono text-xs tabular-nums text-muted">
                {Math.round(hud.speedKmh)} km/h
              </p>
            )}
          </div>
          {hud.prompt && (
            <div className="absolute left-1/2 top-[max(1.25rem,env(safe-area-inset-top))] -translate-x-1/2 rounded-md border border-border bg-surface/80 px-3 py-2 text-center">
              <p className="text-sm text-fg">{hud.prompt}</p>
              {!coarse && (
                <p className="text-xs text-muted">Touche E</p>
              )}
            </div>
          )}
          {!coarse && (
            <div className="absolute bottom-[max(1rem,env(safe-area-inset-bottom))] left-1/2 hidden -translate-x-1/2 rounded-md border border-border bg-surface/60 px-3 py-1.5 text-xs text-muted md:block">
              WASD · Souris · E interagir · Maj courir
            </div>
          )}
        </>
      )}

      {hud.paused && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/70">
          <div className="w-[min(22rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 text-center">
            <h2 className="font-display text-2xl">Pause</h2>
            <p className="mt-2 text-sm text-muted">
              La caméra et les déplacements sont figés.
            </p>
            <Button className="mt-6 w-full" onClick={() => sim.togglePause()}>
              Reprendre
            </Button>
          </div>
        </div>
      )}

      <TouchControls />
    </div>
  );
}

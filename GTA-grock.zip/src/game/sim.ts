import {
  CAM_DIST_CAR,
  CAM_DIST_FOOT,
  CAM_HEIGHT_CAR,
  CAM_HEIGHT_FOOT,
  CAM_LOOK_CAR,
  CAM_LOOK_FOOT,
  CAM_MAX,
  CAM_MIN,
  CAR_ACCEL,
  CAR_BRAKE,
  CAR_DRAG,
  CAR_HALF_L,
  CAR_HALF_W,
  CAR_MAX,
  CAR_MAX_REV,
  CAR_REVERSE,
  CAR_SPAWN,
  CAR_TURN,
  FIXED_DT,
  HOUSE_DOOR,
  INTERACT_CAR,
  INTERACT_DOOR,
  MAX_STEPS,
  PLAYER_HALF_H,
  PLAYER_RADIUS,
  PLAYER_SPAWN,
  PLAYER_SPRINT,
  PLAYER_TURN,
  PLAYER_WALK,
  WORLD_LIMIT,
} from "./constants";
import {
  pushCircleAABB,
  pushCircleCircle,
  pushOBBAgainstAABB,
  rayAABB,
  rayCylinder,
  shortestAngle,
  wrapAngle,
  yOverlap,
  type AABB,
} from "./collision";
import type { SampledInput } from "./input";
import { STATIC_BOXES, STATIC_CYL, doorCollider } from "./worldData";

export type InteractKind = "car-enter" | "car-exit" | "door" | null;

export type HudSnap = {
  started: boolean;
  paused: boolean;
  inVehicle: boolean;
  prompt: string | null;
  interactKind: InteractKind;
  speedKmh: number;
  doorOpen: boolean;
};

const DOOR_COL = doorCollider();

function groundY(): number {
  return PLAYER_HALF_H;
}

export class GameSim {
  started = false;
  paused = false;
  time = 0;

  px = PLAYER_SPAWN.x;
  py = PLAYER_SPAWN.y;
  pz = PLAYER_SPAWN.z;
  pvx = 0;
  pvy = 0;
  pvz = 0;
  yaw = PLAYER_SPAWN.yaw;
  walkPhase = 0;
  grounded = true;
  inVehicle = false;
  visiblePlayer = true;

  cx = CAR_SPAWN.x;
  cy = 0;
  cz = CAR_SPAWN.z;
  cyaw = CAR_SPAWN.yaw;
  cspeed = 0;
  wheel = 0;
  steerVis = 0;

  camYaw = 0;
  camPitch = 0.32;
  camDist = CAM_DIST_FOOT;
  camHitDist = CAM_DIST_FOOT;
  camX = 0;
  camY = 4;
  camZ = 12;
  lookX = 0;
  lookY = 1.4;
  lookZ = 8;

  doorOpen = false;
  doorAngle = 0;
  mountT = 0;
  mountMode: "none" | "enter" | "exit" = "none";
  prompt: string | null = null;
  interactKind: InteractKind = null;

  enterPlayer() {
    this.started = true;
    this.paused = false;
    this.camYaw = this.yaw;
    this.camPitch = 0.36;
    this.camDist = CAM_DIST_FOOT;
    this.camHitDist = CAM_DIST_FOOT;
    this.syncLook();
    this.snapCamera();
  }

  private snapCamera() {
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const cosP = Math.cos(this.camPitch);
    const sinP = Math.sin(this.camPitch);
    const dist = Math.min(this.camDist, 5.2);
    this.camX = this.lookX - fx * dist * cosP;
    this.camY = this.lookY + dist * sinP + 0.2;
    this.camZ = this.lookZ - fz * dist * cosP;
  }

  togglePause() {
    if (!this.started) return;
    this.paused = !this.paused;
  }

  getYaw(): number {
    return this.inVehicle ? this.cyaw : this.yaw;
  }

  getSpeed(): number {
    if (this.inVehicle) return Math.abs(this.cspeed);
    return Math.hypot(this.pvx, this.pvz);
  }

  step(dt: number, inp: SampledInput) {
    const capped = Math.min(Math.max(dt, 0), 0.1);
    this.time += capped;
    if (!this.started) {
      this.updateCinematic();
      this.syncLook();
      return;
    }
    if (this.paused) {
      this.syncLook();
      return;
    }

    this.camYaw -= inp.lookX * 0.0052;
    this.camPitch = Math.max(
      0.06,
      Math.min(1.12, this.camPitch - inp.lookY * 0.0042),
    );
    if (inp.zoom) {
      this.camDist = Math.max(
        CAM_MIN,
        Math.min(CAM_MAX, this.camDist + inp.zoom * 0.004),
      );
    }

    let acc = capped;
    let steps = 0;
    while (acc >= FIXED_DT && steps < MAX_STEPS) {
      this.fixed(FIXED_DT, inp);
      acc -= FIXED_DT;
      steps++;
    }
    if (steps === 0) this.fixed(acc, inp);

    this.doorAngle += ((this.doorOpen ? 1.55 : 0) - this.doorAngle) * (1 - Math.exp(-8 * capped));
    this.updateCamera(capped);
  }

  private updateCinematic() {
    const t = this.time;
    this.camYaw = 0.55 + t * 0.18;
    this.camPitch = 0.28;
    this.camDist = 11.5;
    this.lookX = 0.4;
    this.lookY = 1.35;
    this.lookZ = 2.2;
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    this.camX = this.lookX - fx * this.camDist + 1.2;
    this.camY = 4.6;
    this.camZ = this.lookZ - fz * this.camDist;
  }

  private fixed(dt: number, inp: SampledInput) {
    if (this.mountMode !== "none") {
      this.tickMount(dt);
      this.refreshPrompt();
      return;
    }

    this.refreshPrompt();
    if (inp.interact) this.tryInteract();

    if (this.inVehicle) this.drive(dt, inp);
    else this.walk(dt, inp);

    this.constrainWorld();
  }

  private walk(dt: number, inp: SampledInput) {
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const rx = Math.cos(this.camYaw);
    const rz = -Math.sin(this.camYaw);
    let wx = rx * inp.moveX + fx * inp.moveY;
    let wz = rz * inp.moveX + fz * inp.moveY;
    const wl = Math.hypot(wx, wz);
    const max = inp.sprint ? PLAYER_SPRINT : PLAYER_WALK;
    if (wl > 1e-4) {
      wx /= wl;
      wz /= wl;
      const tyaw = Math.atan2(-wx, -wz);
      this.yaw += shortestAngle(this.yaw, tyaw) * Math.min(1, PLAYER_TURN * dt);
      this.yaw = wrapAngle(this.yaw);
      this.walkPhase += max * dt * 1.9;
    } else {
      this.walkPhase = 0;
    }
    const k = 1 - Math.exp(-14 * dt);
    this.pvx += (wx * max - this.pvx) * k;
    this.pvz += (wz * max - this.pvz) * k;

    this.px += this.pvx * dt;
    this.pz += this.pvz * dt;
    this.resolvePlayer();

    this.pvy -= 28 * dt;
    this.py += this.pvy * dt;
    const g = groundY();
    if (this.py <= g) {
      this.py = g;
      this.pvy = 0;
      this.grounded = true;
    } else {
      this.grounded = false;
    }
    if (this.py > 1.55) {
      this.py = 1.55;
      if (this.pvy > 0) this.pvy = 0;
    }
  }

  private drive(dt: number, inp: SampledInput) {
    const throttle = inp.throttle;
    if (throttle > 0.05) {
      this.cspeed += CAR_ACCEL * throttle * dt;
    } else if (throttle < -0.05) {
      if (this.cspeed > 0.35) this.cspeed -= CAR_BRAKE * -throttle * dt;
      else this.cspeed += -CAR_REVERSE * -throttle * dt;
    }
    this.cspeed *= 1 - CAR_DRAG * dt;
    if (this.cspeed > CAR_MAX) this.cspeed = CAR_MAX;
    if (this.cspeed < -CAR_MAX_REV) this.cspeed = -CAR_MAX_REV;
    if (Math.abs(this.cspeed) < 0.02 && Math.abs(throttle) < 0.05) this.cspeed = 0;

    const speedFactor = Math.min(1, Math.abs(this.cspeed) / 4.2);
    const reverse = this.cspeed >= 0 ? 1 : -1;
    const steer = inp.steer;
    this.cyaw += steer * CAR_TURN * speedFactor * reverse * dt;
    this.cyaw = wrapAngle(this.cyaw);
    this.steerVis += (steer - this.steerVis) * Math.min(1, 10 * dt);
    this.wheel += this.cspeed * dt * 1.55;

    const fx = -Math.sin(this.cyaw);
    const fz = -Math.cos(this.cyaw);
    const subs = 3;
    const sdt = dt / subs;
    for (let i = 0; i < subs; i++) {
      this.cx += fx * this.cspeed * sdt;
      this.cz += fz * this.cspeed * sdt;
      this.resolveCar();
    }

    this.px = this.cx - Math.cos(this.cyaw) * 0.32;
    this.pz = this.cz - Math.sin(this.cyaw) * 0.12;
    this.py = 0.95;
    this.yaw = this.cyaw;
    this.visiblePlayer = false;
  }

  private boxes(): AABB[] {
    const list = STATIC_BOXES.slice();
    if (!this.doorOpen) list.push(DOOR_COL);
    return list;
  }

  private resolvePlayer() {
    const ymin = this.py - PLAYER_HALF_H + 0.08;
    const ymax = this.py + PLAYER_HALF_H - 0.05;
    const boxes = this.boxes();
    for (let n = 0; n < 3; n++) {
      for (const b of boxes) {
        if (!yOverlap(ymin, ymax, b.minY, b.maxY)) continue;
        const p = pushCircleAABB(this.px, this.pz, PLAYER_RADIUS, b);
        if (p) {
          this.px += p.x;
          this.pz += p.z;
        }
      }
      for (const c of STATIC_CYL) {
        if (!yOverlap(ymin, ymax, c.minY, c.maxY)) continue;
        const p = pushCircleCircle(this.px, this.pz, PLAYER_RADIUS, c.x, c.z, c.r);
        if (p) {
          this.px += p.x;
          this.pz += p.z;
        }
      }
      if (!this.inVehicle) {
        const p = this.pushPlayerFromCar();
        if (p) {
          this.px += p.x;
          this.pz += p.z;
        }
      }
    }
  }

  private pushPlayerFromCar(): { x: number; z: number } | null {
    const ymin = this.py - PLAYER_HALF_H;
    const ymax = this.py + PLAYER_HALF_H;
    if (!yOverlap(ymin, ymax, 0, 1.35)) return null;
    return pushCircleCircle(
      this.px,
      this.pz,
      PLAYER_RADIUS,
      this.cx,
      this.cz,
      1.22,
    );
  }

  private resolveCar() {
    const boxes = this.boxes();
    for (let n = 0; n < 3; n++) {
      for (const b of boxes) {
        if (!yOverlap(0.05, 1.25, b.minY, b.maxY)) continue;
        const p = pushOBBAgainstAABB(
          this.cx,
          this.cz,
          this.cyaw,
          CAR_HALF_L,
          CAR_HALF_W,
          b,
        );
        if (p) {
          this.cx += p.x;
          this.cz += p.z;
          this.cspeed *= 0.92;
        }
      }
      for (const c of STATIC_CYL) {
        const p = pushCircleCircle(
          this.cx,
          this.cz,
          Math.max(CAR_HALF_W, 0.95),
          c.x,
          c.z,
          c.r,
        );
        if (p) {
          this.cx += p.x;
          this.cz += p.z;
          this.cspeed *= 0.88;
        }
      }
    }
  }

  private constrainWorld() {
    const lim = WORLD_LIMIT - 0.4;
    this.px = Math.max(-lim, Math.min(lim, this.px));
    this.pz = Math.max(-lim, Math.min(lim, this.pz));
    this.cx = Math.max(-lim, Math.min(lim, this.cx));
    this.cz = Math.max(-lim, Math.min(lim, this.cz));
    if (this.py < -2) {
      this.px = PLAYER_SPAWN.x;
      this.py = PLAYER_SPAWN.y;
      this.pz = PLAYER_SPAWN.z;
      this.pvx = this.pvz = this.pvy = 0;
      this.inVehicle = false;
      this.visiblePlayer = true;
    }
  }

  private carDoorPos() {
    const rx = Math.cos(this.cyaw);
    const rz = -Math.sin(this.cyaw);
    return { x: this.cx - rx * 1.25, z: this.cz - rz * 1.25 };
  }

  private dist2(ax: number, az: number, bx: number, bz: number) {
    const dx = ax - bx;
    const dz = az - bz;
    return dx * dx + dz * dz;
  }

  private refreshPrompt() {
    if (this.inVehicle || this.mountMode === "enter") {
      this.prompt = "Sortir du véhicule";
      this.interactKind = "car-exit";
      return;
    }
    if (this.mountMode === "exit") {
      this.prompt = null;
      this.interactKind = null;
      return;
    }
    const door = this.carDoorPos();
    const dCar = this.dist2(this.px, this.pz, door.x, door.z);
    const dDoor = this.dist2(this.px, this.pz, HOUSE_DOOR.x, HOUSE_DOOR.z);
    const carOk = dCar < INTERACT_CAR * INTERACT_CAR;
    const doorOk = dDoor < INTERACT_DOOR * INTERACT_DOOR;
    if (carOk && (!doorOk || dCar <= dDoor)) {
      this.prompt = "Entrer dans le véhicule";
      this.interactKind = "car-enter";
      return;
    }
    if (doorOk) {
      this.prompt = this.doorOpen ? "Fermer la porte" : "Ouvrir la porte";
      this.interactKind = "door";
      return;
    }
    this.prompt = null;
    this.interactKind = null;
  }

  private tryInteract() {
    if (this.interactKind === "door") {
      this.doorOpen = !this.doorOpen;
      return;
    }
    if (this.interactKind === "car-enter") {
      this.mountMode = "enter";
      this.mountT = 0;
      return;
    }
    if (this.interactKind === "car-exit") {
      this.mountMode = "exit";
      this.mountT = 0;
      this.visiblePlayer = true;
      this.inVehicle = false;
    }
  }

  private tickMount(dt: number) {
    this.mountT += dt / 0.42;
    const t = Math.min(1, this.mountT);
    if (this.mountMode === "enter") {
      const seatX = this.cx - Math.cos(this.cyaw) * 0.32;
      const seatZ = this.cz - Math.sin(this.cyaw) * 0.1;
      const door = this.carDoorPos();
      const mid = t < 0.55 ? t / 0.55 : 1;
      const a = t < 0.55 ? 1 : (t - 0.55) / 0.45;
      if (t < 0.55) {
        this.px += (door.x - this.px) * (1 - Math.pow(1 - mid, 2));
        this.pz += (door.z - this.pz) * (1 - Math.pow(1 - mid, 2));
      } else {
        this.px = door.x + (seatX - door.x) * a;
        this.pz = door.z + (seatZ - door.z) * a;
        this.py = PLAYER_HALF_H + 0.12 * a;
      }
      this.yaw += shortestAngle(this.yaw, this.cyaw) * 0.2;
      this.visiblePlayer = t < 0.92;
      if (t >= 1) {
        this.inVehicle = true;
        this.mountMode = "none";
        this.visiblePlayer = false;
        this.cspeed = 0;
      }
    } else {
      const left = this.exitSpot();
      this.px += (left.x - this.px) * (1 - Math.exp(-10 * dt));
      this.pz += (left.z - this.pz) * (1 - Math.exp(-10 * dt));
      this.py = PLAYER_HALF_H;
      this.visiblePlayer = true;
      this.yaw = this.cyaw;
      if (t >= 1) {
        this.px = left.x;
        this.pz = left.z;
        this.mountMode = "none";
        this.inVehicle = false;
        this.resolvePlayer();
      }
    }
  }

  private exitSpot() {
    const rx = Math.cos(this.cyaw);
    const rz = -Math.sin(this.cyaw);
    const candidates = [
      { x: this.cx - rx * 1.7, z: this.cz - rz * 1.7 },
      { x: this.cx + rx * 1.7, z: this.cz + rz * 1.7 },
      { x: this.cx - rx * 1.7 + Math.sin(this.cyaw) * 1.4, z: this.cz - rz * 1.7 + Math.cos(this.cyaw) * 1.4 },
    ];
    for (const c of candidates) {
      const saved = { x: this.px, z: this.pz };
      this.px = c.x;
      this.pz = c.z;
      this.resolvePlayer();
      const moved = Math.hypot(this.px - c.x, this.pz - c.z);
      const pos = { x: this.px, z: this.pz };
      this.px = saved.x;
      this.pz = saved.z;
      if (moved < 0.45) return pos;
    }
    return candidates[0];
  }

  private updateCamera(dt: number) {
    this.syncLook();
    const driving = this.inVehicle || this.mountMode === "enter";
    const desired = driving ? CAM_DIST_CAR : Math.min(this.camDist, CAM_DIST_FOOT + 1.2);
    const height = driving ? CAM_HEIGHT_CAR : CAM_HEIGHT_FOOT;
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const cosP = Math.cos(this.camPitch);
    const sinP = Math.sin(this.camPitch);
    const ox = this.lookX - fx * desired * cosP;
    const oy = this.lookY + desired * sinP + (driving ? 0.35 : 0.15);
    const oz = this.lookZ - fz * desired * cosP;

    const dx = ox - this.lookX;
    const dy = oy - this.lookY;
    const dz = oz - this.lookZ;
    const len = Math.hypot(dx, dy, dz) || 1;
    const ux = dx / len;
    const uy = dy / len;
    const uz = dz / len;
    let tHit = len;
    const boxes = this.boxes();
    for (const b of boxes) {
      const t = rayAABB(this.lookX, this.lookY, this.lookZ, ux, uy, uz, b, tHit);
      if (t < tHit) tHit = t;
    }
    for (const c of STATIC_CYL) {
      const t = rayCylinder(this.lookX, this.lookY, this.lookZ, ux, uy, uz, c, tHit);
      if (t < tHit) tHit = t;
    }
    tHit = Math.max(0.55, tHit - 0.22);
    const follow = tHit < this.camHitDist ? 18 : 7;
    this.camHitDist += (tHit - this.camHitDist) * (1 - Math.exp(-follow * dt));

    const tx = this.lookX + ux * this.camHitDist;
    const ty = this.lookY + uy * this.camHitDist;
    const tz = this.lookZ + uz * this.camHitDist;
    const s = 1 - Math.exp(-11 * dt);
    this.camX += (tx - this.camX) * s;
    this.camY += (ty - this.camY) * s;
    this.camZ += (tz - this.camZ) * s;
  }

  private syncLook() {
    if (!this.started) return;
    const driving = this.inVehicle;
    this.lookX = driving ? this.cx : this.px;
    this.lookZ = driving ? this.cz : this.pz;
    this.lookY = driving ? CAM_LOOK_CAR : this.py - PLAYER_HALF_H + CAM_LOOK_FOOT;
  }

  hud(): HudSnap {
    return {
      started: this.started,
      paused: this.paused,
      inVehicle: this.inVehicle,
      prompt: this.started ? this.prompt : null,
      interactKind: this.interactKind,
      speedKmh: Math.abs(this.cspeed) * 3.6,
      doorOpen: this.doorOpen,
    };
  }
}

export const sim = new GameSim();

import { Canvas } from "@react-three/fiber";
import { useEffect, useRef } from "react";
import { Overlay } from "./Overlay";
import { Scene } from "./Scene";
import { input } from "./input";
import { sim } from "./sim";

export default function GameApp() {
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const off = input.attach();
    const el = wrap.current;
    if (!el) return off;

    const lookPid = { id: null as number | null, x: 0, y: 0 };

    const down = (e: PointerEvent) => {
      if (!sim.started || sim.paused) return;
      const t = e.target as HTMLElement;
      if (t.closest("button, [data-touch-ui]")) return;
      if (e.pointerType === "touch") {
        const rect = el.getBoundingClientRect();
        if (e.clientX < rect.left + rect.width * 0.42) return;
      }
      lookPid.id = e.pointerId;
      lookPid.x = e.clientX;
      lookPid.y = e.clientY;
      el.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (lookPid.id !== e.pointerId) return;
      input.addLook(e.clientX - lookPid.x, e.clientY - lookPid.y);
      lookPid.x = e.clientX;
      lookPid.y = e.clientY;
    };
    const up = (e: PointerEvent) => {
      if (lookPid.id === e.pointerId) lookPid.id = null;
    };
    const wheel = (e: WheelEvent) => {
      if (!sim.started) return;
      e.preventDefault();
      input.addZoom(e.deltaY);
    };

    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    el.addEventListener("wheel", wheel, { passive: false });
    return () => {
      off();
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
      el.removeEventListener("wheel", wheel);
    };
  }, []);

  return (
    <div
      ref={wrap}
      className="relative h-[100dvh] w-full touch-none overflow-hidden bg-bg"
    >
      <Canvas
        shadows
        dpr={[1, 1.5]}
        camera={{ fov: 62, near: 0.12, far: 90, position: [6, 5, 14] }}
        gl={{
          antialias: true,
          powerPreference: "high-performance",
          toneMappingExposure: 1.05,
        }}
        onContextMenu={(e) => e.preventDefault()}
      >
        <Scene />
      </Canvas>
      <Overlay />
    </div>
  );
}

import { create } from "zustand";
import type { HudSnap } from "./sim";

export const useHud = create<HudSnap>(() => ({
  started: false,
  paused: false,
  inVehicle: false,
  prompt: null,
  interactKind: null,
  speedKmh: 0,
  doorOpen: false,
}));

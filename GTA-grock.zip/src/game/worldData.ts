import { HOUSE, WORLD_LIMIT } from "./constants";
import type { AABB, Cylinder } from "./collision";

function box(
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
): AABB {
  const hx = sx * 0.5;
  const hz = sz * 0.5;
  return {
    minX: x - hx,
    maxX: x + hx,
    minY: y,
    maxY: y + sy,
    minZ: z - hz,
    maxZ: z + hz,
  };
}

function wallBox(
  minX: number,
  maxX: number,
  minZ: number,
  maxZ: number,
  minY: number,
  maxY: number,
): AABB {
  return { minX, maxX, minY, maxY, minZ, maxZ };
}

export function houseColliders(): AABB[] {
  const { x0, x1, z0, z1, wall, height, doorZ0, doorZ1, doorH } = HOUSE;
  const list: AABB[] = [
    wallBox(x0, x0 + wall, z0, z1, 0, height),
    wallBox(x0, x1, z0, z0 + wall, 0, height),
    wallBox(x0, x1, z1 - wall, z1, 0, height),
    wallBox(x1 - wall, x1, z0, doorZ0, 0, height),
    wallBox(x1 - wall, x1, doorZ1, z1, 0, height),
    wallBox(x1 - wall, x1, doorZ0, doorZ1, doorH, height),
    wallBox(x0, x1, z0, z1, height - 0.08, 3.85),
  ];
  return list;
}

export function doorCollider(): AABB {
  const { x1, wall, doorZ0, doorZ1, doorH } = HOUSE;
  return wallBox(x1 - wall, x1 + 0.04, doorZ0, doorZ1, 0, doorH);
}

export const HOUSE2 = {
  x: 9.35,
  z: 2.55,
  sx: 6.4,
  sz: 5.5,
  h: 2.85,
} as const;

export const SHOP = {
  x: -9.55,
  z: 8.95,
  sx: 7.5,
  sz: 5.15,
  h: 3.35,
} as const;

export const TREES: Cylinder[] = [
  { x: 6.45, z: -8.2, r: 0.32, minY: 0, maxY: 5.2 },
  { x: -6.35, z: 12.4, r: 0.3, minY: 0, maxY: 5.2 },
  { x: 11.15, z: -6.1, r: 0.28, minY: 0, maxY: 4.8 },
  { x: -12.2, z: 12.55, r: 0.42, minY: 0, maxY: 4.6 },
];

export const POSTS: Cylinder[] = [
  { x: -3.95, z: -10.2, r: 0.1, minY: 0, maxY: 3.4 },
  { x: -3.95, z: 1.8, r: 0.1, minY: 0, maxY: 3.4 },
  { x: -3.95, z: 12.1, r: 0.1, minY: 0, maxY: 3.4 },
  { x: 3.95, z: -6.4, r: 0.1, minY: 0, maxY: 3.4 },
  { x: 3.95, z: 6.6, r: 0.1, minY: 0, maxY: 3.4 },
];

function perimeter(): AABB[] {
  const t = 1.15;
  const h = 3.6;
  const L = WORLD_LIMIT + 0.55;
  return [
    box(0, 0, L, 34, h, t),
    box(0, 0, -L, 34, h, t),
    box(L, 0, 0, t, h, 34),
    box(-L, 0, 0, t, h, 34),
  ];
}

export function staticBoxes(): AABB[] {
  return [
    ...houseColliders(),
    box(HOUSE2.x, 0, HOUSE2.z, HOUSE2.sx, HOUSE2.h, HOUSE2.sz),
    box(SHOP.x, 0, SHOP.z, SHOP.sx, SHOP.h, SHOP.sz),
    box(-8.2, 0, -4.15, 2.05, 0.72, 0.85),
    box(-8.2, 0, -3.05, 0.95, 0.38, 0.62),
    box(-11.6, 0, -1.0, 0.62, 0.92, 2.35),
    box(-11.6, 0, 0.45, 0.58, 1.62, 0.55),
    box(-6.5, 0, 0.15, 1.85, 0.48, 1.35),
    box(5.35, 0, 11.45, 1.15, 1.15, 0.78),
    box(-5.05, 0, 11.2, 1.05, 1.12, 0.72),
    box(12.15, 0, -1.4, 0.28, 0.85, 6.2),
    box(9.4, 0, -1.35, 5.6, 1.15, 0.12),
    box(6.62, 0, 0.7, 0.12, 1.15, 4.1),
    box(-4.95, 0, -3.55, 0.28, 1.05, 0.22),
    box(4.05, 0, -2.85, 0.28, 0.72, 0.28),
    box(-3.72, 0, -14.05, 0.18, 2.35, 0.18),
    box(5.55, 0, 4.85, 0.85, 1.05, 0.22),
    ...perimeter(),
  ];
}

export const STATIC_BOXES = staticBoxes();
export const STATIC_CYL = [...TREES, ...POSTS];

export const SKYLINE = [
  { x: -22, z: 8, sx: 6, h: 9, sz: 5, color: "#8a7a6a" },
  { x: -24, z: -6, sx: 5, h: 7, sz: 6, color: "#6e7b7a" },
  { x: 22, z: 4, sx: 7, h: 11, sz: 5, color: "#7c6d62" },
  { x: 23, z: -10, sx: 5, h: 6.5, sz: 5, color: "#8d8474" },
  { x: -6, z: 24, sx: 8, h: 8, sz: 5, color: "#6f6860" },
  { x: 8, z: 25, sx: 6, h: 10, sz: 4.5, color: "#7a6b5c" },
  { x: 2, z: -24, sx: 9, h: 7.5, sz: 5, color: "#65706c" },
  { x: -12, z: -23, sx: 5, h: 5.5, sz: 4, color: "#8b735e" },
] as const;

export type SampledInput = {
  moveX: number;
  moveY: number;
  steer: number;
  throttle: number;
  sprint: boolean;
  interact: boolean;
  lookX: number;
  lookY: number;
  zoom: number;
};

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "ShiftLeft",
  "ShiftRight",
  "KeyE",
  "KeyF",
  "Space",
  "Escape",
]);

function radial(x: number, y: number, dz = 0.16): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

class Input {
  keys = new Set<string>();
  injected: Set<string> | null = null;
  prev = new Set<string>();
  lookAccX = 0;
  lookAccY = 0;
  zoomAcc = 0;
  stickX = 0;
  stickY = 0;
  lookStickX = 0;
  lookStickY = 0;
  sprintTouch = false;
  interactHeld = false;
  interactPrev = false;
  dragging = false;
  pointerId: number | null = null;

  attach() {
    const down = (e: KeyboardEvent) => {
      if (GAME_CODES.has(e.code)) e.preventDefault();
      this.keys.add(e.code);
    };
    const up = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };
    const clear = () => this.keys.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) clear();
    });
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
    };
  }

  addLook(dx: number, dy: number) {
    this.lookAccX += dx;
    this.lookAccY += dy;
  }

  addZoom(d: number) {
    this.zoomAcc += d;
  }

  setKeys(codes: string[]) {
    this.injected = new Set(codes);
  }

  private held(): Set<string> {
    return this.injected ?? this.keys;
  }

  sample(dt: number): SampledInput {
    this.pollGamepad();
    const held = this.held();
    let moveX = this.stickX;
    let moveY = this.stickY;
    if (held.has("KeyA") || held.has("ArrowLeft")) moveX -= 1;
    if (held.has("KeyD") || held.has("ArrowRight")) moveX += 1;
    if (held.has("KeyW") || held.has("ArrowUp")) moveY += 1;
    if (held.has("KeyS") || held.has("ArrowDown")) moveY -= 1;
    const ml = Math.hypot(moveX, moveY);
    if (ml > 1) {
      moveX /= ml;
      moveY /= ml;
    }

    let steer = 0;
    if (held.has("KeyA") || held.has("ArrowLeft")) steer += 1;
    if (held.has("KeyD") || held.has("ArrowRight")) steer -= 1;
    steer += -this.stickX;
    steer = Math.max(-1, Math.min(1, steer));

    let throttle = this.stickY;
    if (held.has("KeyW") || held.has("ArrowUp")) throttle += 1;
    if (held.has("KeyS") || held.has("ArrowDown")) throttle -= 1;
    throttle = Math.max(-1, Math.min(1, throttle));

    const sprint =
      this.sprintTouch || held.has("ShiftLeft") || held.has("ShiftRight");

    const interactKey =
      (held.has("KeyE") && !this.prev.has("KeyE")) ||
      (held.has("KeyF") && !this.prev.has("KeyF")) ||
      (held.has("Space") && !this.prev.has("Space"));
    const interactTouch = this.interactHeld && !this.interactPrev;
    this.interactPrev = this.interactHeld;
    this.prev = new Set(held);

    const lookX = this.lookAccX + this.lookStickX * 2.4 * dt * 60;
    const lookY = this.lookAccY + this.lookStickY * 2.0 * dt * 60;
    const zoom = this.zoomAcc;
    this.lookAccX = 0;
    this.lookAccY = 0;
    this.zoomAcc = 0;

    return {
      moveX,
      moveY,
      steer,
      throttle,
      sprint,
      interact: interactKey || interactTouch,
      lookX,
      lookY,
      zoom,
    };
  }

  pollGamepad() {
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (!pad || pad.mapping !== "standard") continue;
      const ls = radial(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
      this.stickX = ls.x;
      this.stickY = -ls.y;
      const rs = radial(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.12);
      this.lookStickX = rs.x;
      this.lookStickY = rs.y;
      if (pad.buttons[0]?.pressed) this.interactHeld = true;
      if (pad.buttons[1]?.pressed) this.sprintTouch = true;
      return;
    }
  }
}

export const input = new Input();

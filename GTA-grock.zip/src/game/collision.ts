export type AABB = {
  minX: number;
  minY: number;
  minZ: number;
  maxX: number;
  maxY: number;
  maxZ: number;
};

export type Cylinder = {
  x: number;
  z: number;
  r: number;
  minY: number;
  maxY: number;
};

export function yOverlap(
  aMin: number,
  aMax: number,
  bMin: number,
  bMax: number,
): boolean {
  return aMax > bMin && aMin < bMax;
}

export function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

export function shortestAngle(from: number, to: number): number {
  return Math.atan2(Math.sin(to - from), Math.cos(to - from));
}

export function wrapAngle(a: number): number {
  return Math.atan2(Math.sin(a), Math.cos(a));
}

/** Push a vertical cylinder out of an AABB on XZ. Returns penetration push. */
export function pushCircleAABB(
  px: number,
  pz: number,
  radius: number,
  b: AABB,
): { x: number; z: number } | null {
  const qx = clamp(px, b.minX, b.maxX);
  const qz = clamp(pz, b.minZ, b.maxZ);
  let dx = px - qx;
  let dz = pz - qz;
  const d2 = dx * dx + dz * dz;

  if (d2 > 1e-10) {
    if (d2 >= radius * radius) return null;
    const d = Math.sqrt(d2);
    const pen = radius - d;
    return { x: (dx / d) * pen, z: (dz / d) * pen };
  }

  const left = px - b.minX;
  const right = b.maxX - px;
  const south = pz - b.minZ;
  const north = b.maxZ - pz;
  const m = Math.min(left, right, south, north);
  if (m === left) return { x: -(left + radius), z: 0 };
  if (m === right) return { x: right + radius, z: 0 };
  if (m === south) return { x: 0, z: -(south + radius) };
  return { x: 0, z: north + radius };
}

export function pushCircleCircle(
  px: number,
  pz: number,
  pr: number,
  ox: number,
  oz: number,
  or: number,
): { x: number; z: number } | null {
  const dx = px - ox;
  const dz = pz - oz;
  const min = pr + or;
  const d2 = dx * dx + dz * dz;
  if (d2 >= min * min) return null;
  if (d2 < 1e-10) return { x: min, z: 0 };
  const d = Math.sqrt(d2);
  const pen = min - d;
  return { x: (dx / d) * pen, z: (dz / d) * pen };
}

function project(pts: Array<[number, number]>, ax: number, az: number) {
  let min = Infinity;
  let max = -Infinity;
  for (const [x, z] of pts) {
    const p = x * ax + z * az;
    if (p < min) min = p;
    if (p > max) max = p;
  }
  return { min, max };
}

/**
 * 2D SAT: oriented car rectangle vs AABB. MTV on XZ, pointing out of the box.
 */
export function pushOBBAgainstAABB(
  ox: number,
  oz: number,
  yaw: number,
  halfL: number,
  halfW: number,
  b: AABB,
): { x: number; z: number } | null {
  const fx = -Math.sin(yaw);
  const fz = -Math.cos(yaw);
  const rx = Math.cos(yaw);
  const rz = -Math.sin(yaw);

  const corners: Array<[number, number]> = [
    [ox + fx * halfL + rx * halfW, oz + fz * halfL + rz * halfW],
    [ox + fx * halfL - rx * halfW, oz + fz * halfL - rz * halfW],
    [ox - fx * halfL + rx * halfW, oz - fz * halfL + rz * halfW],
    [ox - fx * halfL - rx * halfW, oz - fz * halfL - rz * halfW],
  ];
  const boxPts: Array<[number, number]> = [
    [b.minX, b.minZ],
    [b.maxX, b.minZ],
    [b.minX, b.maxZ],
    [b.maxX, b.maxZ],
  ];

  const axes: Array<[number, number]> = [
    [1, 0],
    [0, 1],
    [fx, fz],
    [rx, rz],
  ];

  let minPen = Infinity;
  let nx = 0;
  let nz = 0;

  for (const [ax, az] of axes) {
    const len = Math.hypot(ax, az) || 1;
    const ux = ax / len;
    const uz = az / len;
    const a = project(corners, ux, uz);
    const c = project(boxPts, ux, uz);
    const overlap = Math.min(a.max, c.max) - Math.max(a.min, c.min);
    if (overlap <= 0) return null;
    if (overlap < minPen) {
      minPen = overlap;
      nx = ux;
      nz = uz;
    }
  }

  const boxCx = (b.minX + b.maxX) * 0.5;
  const boxCz = (b.minZ + b.maxZ) * 0.5;
  if ((ox - boxCx) * nx + (oz - boxCz) * nz < 0) {
    nx = -nx;
    nz = -nz;
  }
  return { x: nx * minPen, z: nz * minPen };
}

export function rayAABB(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  b: AABB,
  maxT: number,
): number {
  let tmin = 0;
  let tmax = maxT;
  if (Math.abs(dx) < 1e-8) {
    if (ox < b.minX || ox > b.maxX) return maxT + 1;
  } else {
    let t1 = (b.minX - ox) / dx;
    let t2 = (b.maxX - ox) / dx;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return maxT + 1;
  }
  if (Math.abs(dy) < 1e-8) {
    if (oy < b.minY || oy > b.maxY) return maxT + 1;
  } else {
    let t1 = (b.minY - oy) / dy;
    let t2 = (b.maxY - oy) / dy;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return maxT + 1;
  }
  if (Math.abs(dz) < 1e-8) {
    if (oz < b.minZ || oz > b.maxZ) return maxT + 1;
  } else {
    let t1 = (b.minZ - oz) / dz;
    let t2 = (b.maxZ - oz) / dz;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return maxT + 1;
  }
  if (tmax < 0) return maxT + 1;
  const t = tmin >= 0 ? tmin : tmax;
  if (t < 0 || t > maxT) return maxT + 1;
  return t;
}

export function rayCylinder(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  c: Cylinder,
  maxT: number,
): number {
  const ex = ox - c.x;
  const ez = oz - c.z;
  const a = dx * dx + dz * dz;
  const b = 2 * (ex * dx + ez * dz);
  const cc = ex * ex + ez * ez - c.r * c.r;
  let tHit = maxT + 1;
  if (a > 1e-10) {
    const disc = b * b - 4 * a * cc;
    if (disc >= 0) {
      const t = (-b - Math.sqrt(disc)) / (2 * a);
      if (t >= 0 && t <= maxT) {
        const y = oy + dy * t;
        if (y >= c.minY && y <= c.maxY) tHit = t;
      }
    }
  }
  return tHit;
}

export const FIXED_DT = 1 / 60;
export const MAX_STEPS = 6;

export const WORLD_LIMIT = 15.7;

export const PLAYER_RADIUS = 0.34;
export const PLAYER_HALF_H = 0.88;
export const PLAYER_EYE = 1.52;
export const PLAYER_WALK = 3.35;
export const PLAYER_SPRINT = 6.15;
export const PLAYER_TURN = 10.5;

export const CAR_HALF_L = 1.72;
export const CAR_HALF_W = 0.78;
export const CAR_HEIGHT = 1.38;
export const CAR_ACCEL = 9.2;
export const CAR_BRAKE = 16;
export const CAR_REVERSE = 5.4;
export const CAR_MAX = 11.5;
export const CAR_MAX_REV = 4.2;
export const CAR_DRAG = 1.15;
export const CAR_TURN = 1.85;

export const CAM_DIST_FOOT = 4.15;
export const CAM_DIST_CAR = 6.4;
export const CAM_HEIGHT_FOOT = 1.62;
export const CAM_HEIGHT_CAR = 1.85;
export const CAM_LOOK_FOOT = 1.28;
export const CAM_LOOK_CAR = 1.15;
export const CAM_MIN = 1.15;
export const CAM_MAX = 8.5;

export const INTERACT_CAR = 2.15;
export const INTERACT_DOOR = 1.7;

export const PLAYER_SPAWN = { x: 0.2, y: PLAYER_HALF_H, z: 9.4, yaw: 0 };
export const CAR_SPAWN = { x: 1.62, y: 0, z: 3.35, yaw: 0 };

export const HOUSE = {
  x0: -12.55,
  x1: -5.45,
  z0: -5.15,
  z1: 1.25,
  wall: 0.3,
  height: 2.72,
  doorZ0: -2.72,
  doorZ1: -1.22,
  doorH: 2.18,
} as const;

export const HOUSE_DOOR = {
  x: HOUSE.x1,
  z: (HOUSE.doorZ0 + HOUSE.doorZ1) * 0.5,
};

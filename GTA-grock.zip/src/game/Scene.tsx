import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Sky } from "@react-three/drei";
import { World } from "./World";
import { CharacterMesh } from "./CharacterMesh";
import { CarMesh } from "./CarMesh";
import { sim } from "./sim";
import { input } from "./input";
import { useHud } from "./hudState";

function Systems() {
  const { camera } = useThree();
  const escPrev = useRef(false);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);
    const held = input.injected ?? input.keys;
    const esc = held.has("Escape");
    if (esc && !escPrev.current && sim.started) sim.togglePause();
    escPrev.current = esc;

    const inp = input.sample(dt);
    sim.step(dt, inp);
    camera.up.set(0, 1, 0);
    camera.position.set(sim.camX, sim.camY, sim.camZ);
    camera.lookAt(sim.lookX, sim.lookY, sim.lookZ);

    const h = sim.hud();
    const cur = useHud.getState();
    if (
      cur.started !== h.started ||
      cur.paused !== h.paused ||
      cur.inVehicle !== h.inVehicle ||
      cur.prompt !== h.prompt ||
      Math.abs(cur.speedKmh - h.speedKmh) > 0.4
    ) {
      useHud.setState(h);
    }
  });
  return null;
}

export function Scene() {
  useEffect(() => {
    const w = window as Window & {
      __controlsTest?: {
        getYaw: () => number;
        getSpeed: () => number;
        setKeys: (codes: string[]) => void;
        setSteer?: (v: number) => void;
        getCam?: () => unknown;
      };
    };
    w.__controlsTest = {
      getYaw: () => sim.getYaw(),
      getSpeed: () => sim.getSpeed(),
      getCam: () => ({
        cam: [sim.camX, sim.camY, sim.camZ],
        look: [sim.lookX, sim.lookY, sim.lookZ],
        pitch: sim.camPitch,
        yaw: sim.camYaw,
        player: [sim.px, sim.py, sim.pz],
        dist: sim.camHitDist,
        inVehicle: sim.inVehicle,
        prompt: sim.prompt,
        doorOpen: sim.doorOpen,
        car: [sim.cx, sim.cz, sim.cyaw],
      }),
      setKeys: (codes: string[]) => {
        input.setKeys(codes);
        if (codes.length > 0) sim.enterPlayer();
      },
      place: (x: number, z: number) => {
        sim.px = x;
        sim.pz = z;
        sim.py = 0.88;
        sim.pvx = 0;
        sim.pvz = 0;
        sim.inVehicle = false;
        sim.visiblePlayer = true;
        sim.mountMode = "none";
        sim.enterPlayer();
      },
    };
    return () => {
      delete w.__controlsTest;
    };
  }, []);

  return (
    <>
      <color attach="background" args={["#9bb4c2"]} />
      <fog attach="fog" args={["#b7c2bc", 24, 62]} />
      <hemisphereLight args={["#f3e2c4", "#3d4a32", 0.82]} />
      <ambientLight intensity={0.22} />
      <directionalLight
        position={[16, 18, 10]}
        intensity={1.55}
        color="#ffd4aa"
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-near={2}
        shadow-camera-far={55}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
        shadow-bias={-0.00035}
      />
      <Sky
        sunPosition={[16, 7.5, 10]}
        turbidity={5.5}
        rayleigh={1.15}
        mieCoefficient={0.006}
        mieDirectionalG={0.78}
      />
      <World />
      <CharacterMesh />
      <CarMesh />
      <Systems />
    </>
  );
}

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { HOUSE, HOUSE_DOOR } from "./constants";
import { getMaterials } from "./materials";
import { HOUSE2, SHOP, SKYLINE, TREES } from "./worldData";
import { sim } from "./sim";

function Block({
  position,
  size,
  material,
  cast = true,
  receive = true,
}: {
  position: [number, number, number];
  size: [number, number, number];
  material: THREE.Material;
  cast?: boolean;
  receive?: boolean;
}) {
  return (
    <mesh
      position={position}
      material={material}
      castShadow={cast}
      receiveShadow={receive}
    >
      <boxGeometry args={size} />
    </mesh>
  );
}

function Roof({
  x,
  z,
  sx,
  sz,
  y,
  material,
}: {
  x: number;
  z: number;
  sx: number;
  sz: number;
  y: number;
  material: THREE.Material;
}) {
  return (
    <group position={[x, y, z]}>
      <mesh
        rotation={[0, 0, 0.38]}
        position={[sx * 0.18, 0.35, 0]}
        material={material}
        castShadow
      >
        <boxGeometry args={[sx * 0.72, 0.12, sz + 0.3]} />
      </mesh>
      <mesh
        rotation={[0, 0, -0.38]}
        position={[-sx * 0.18, 0.35, 0]}
        material={material}
        castShadow
      >
        <boxGeometry args={[sx * 0.72, 0.12, sz + 0.3]} />
      </mesh>
    </group>
  );
}

function Palm({ x, z, h = 4.6 }: { x: number; z: number; h?: number }) {
  const mats = getMaterials();
  const fronds = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const a = (i / 7) * Math.PI * 2;
      return {
        rot: [1.05, a, 0] as [number, number, number],
        pos: [Math.sin(a) * 0.15, h, Math.cos(a) * 0.15] as [
          number,
          number,
          number,
        ],
      };
    });
  }, [h]);
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, h * 0.45, 0]} material={mats.trunk} castShadow>
        <cylinderGeometry args={[0.12, 0.22, h * 0.9, 8]} />
      </mesh>
      {fronds.map((f, i) => (
        <mesh
          key={i}
          position={f.pos}
          rotation={f.rot}
          material={mats.foliage}
          castShadow
        >
          <coneGeometry args={[0.85, 1.7, 6]} />
        </mesh>
      ))}
    </group>
  );
}

function Leafy({ x, z }: { x: number; z: number }) {
  const mats = getMaterials();
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 1.1, 0]} material={mats.trunk} castShadow>
        <cylinderGeometry args={[0.18, 0.28, 2.2, 8]} />
      </mesh>
      <mesh position={[0, 2.7, 0]} material={mats.foliage} castShadow>
        <sphereGeometry args={[1.35, 10, 8]} />
      </mesh>
      <mesh position={[0.55, 2.3, 0.3]} material={mats.foliage} castShadow>
        <sphereGeometry args={[0.7, 8, 6]} />
      </mesh>
      <mesh position={[-0.5, 2.45, -0.25]} material={mats.foliage} castShadow>
        <sphereGeometry args={[0.65, 8, 6]} />
      </mesh>
    </group>
  );
}

function Lamp({ x, z }: { x: number; z: number }) {
  const mats = getMaterials();
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 1.55, 0]} material={mats.metal} castShadow>
        <cylinderGeometry args={[0.07, 0.09, 3.1, 8]} />
      </mesh>
      <mesh position={[0.35, 3.05, 0]} material={mats.metal}>
        <boxGeometry args={[0.7, 0.06, 0.08]} />
      </mesh>
      <mesh position={[0.62, 2.92, 0]}>
        <boxGeometry args={[0.28, 0.16, 0.28]} />
        <meshStandardMaterial
          color="#efe6c8"
          emissive="#d8c48a"
          emissiveIntensity={0.55}
        />
      </mesh>
    </group>
  );
}

function Door() {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    const g = ref.current;
    if (!g) return;
    g.rotation.y = -sim.doorAngle;
  });
  const hingeZ = HOUSE.doorZ0;
  const leaf = HOUSE.doorZ1 - HOUSE.doorZ0;
  return (
    <group ref={ref} position={[HOUSE.x1 - 0.02, 0, hingeZ]}>
      <mesh position={[0.02, HOUSE.doorH * 0.5, leaf * 0.5]} castShadow>
        <boxGeometry args={[0.08, HOUSE.doorH, leaf - 0.04]} />
        <meshStandardMaterial color="#5c3d2e" roughness={0.7} />
      </mesh>
      <mesh position={[-0.01, 1.05, leaf * 0.78]}>
        <sphereGeometry args={[0.045, 8, 8]} />
        <meshStandardMaterial color="#c4b48a" metalness={0.6} roughness={0.3} />
      </mesh>
    </group>
  );
}

function EnterableHouse() {
  const m = getMaterials();
  const { x0, x1, z0, z1, wall, height, doorZ0, doorZ1, doorH } = HOUSE;
  const cx = (x0 + x1) * 0.5;
  const cz = (z0 + z1) * 0.5;
  const sx = x1 - x0;
  const sz = z1 - z0;
  const innerY = height * 0.5;
  return (
    <group>
      <Block
        position={[x0 + wall * 0.5, innerY, cz]}
        size={[wall, height, sz]}
        material={m.stuccoCream}
      />
      <Block
        position={[cx, innerY, z0 + wall * 0.5]}
        size={[sx, height, wall]}
        material={m.stuccoCream}
      />
      <Block
        position={[cx, innerY, z1 - wall * 0.5]}
        size={[sx, height, wall]}
        material={m.stuccoCream}
      />
      <Block
        position={[
          x1 - wall * 0.5,
          innerY,
          (z0 + doorZ0) * 0.5,
        ]}
        size={[wall, height, doorZ0 - z0]}
        material={m.stuccoCream}
      />
      <Block
        position={[
          x1 - wall * 0.5,
          innerY,
          (doorZ1 + z1) * 0.5,
        ]}
        size={[wall, height, z1 - doorZ1]}
        material={m.stuccoCream}
      />
      <Block
        position={[x1 - wall * 0.5, (doorH + height) * 0.5, HOUSE_DOOR.z]}
        size={[wall, height - doorH, doorZ1 - doorZ0]}
        material={m.stuccoCream}
      />
      <mesh
        position={[cx, 0.02, cz]}
        rotation={[-Math.PI / 2, 0, 0]}
        material={m.wood}
        receiveShadow
      >
        <planeGeometry args={[sx - wall * 2 + 0.02, sz - wall * 2 + 0.02]} />
      </mesh>
      <Block
        position={[cx, height - 0.04, cz]}
        size={[sx - 0.1, 0.08, sz - 0.1]}
        material={m.stuccoInside}
        cast={false}
      />
      <Roof x={cx} z={cz} sx={sx + 0.5} sz={sz + 0.35} y={height} material={m.roof} />
      <mesh position={[x0 + 0.55, height + 0.9, cz]} material={m.brick} castShadow>
        <boxGeometry args={[0.45, 0.9, 0.45]} />
      </mesh>
      <mesh position={[cx, 1.4, z0 + 0.12]} material={m.glass}>
        <boxGeometry args={[1.4, 1.1, 0.06]} />
      </mesh>
      <mesh position={[cx, 1.4, z1 - 0.12]} material={m.glass}>
        <boxGeometry args={[1.4, 1.1, 0.06]} />
      </mesh>
      <Block
        position={[(x1 + 0.55), 0.06, HOUSE_DOOR.z]}
        size={[1.15, 0.1, 1.7]}
        material={m.sidewalk}
        cast={false}
      />
      <Door />
      <Block
        position={[-8.2, 0.36, -4.15]}
        size={[2.05, 0.72, 0.85]}
        material={m.trim}
      />
      <mesh position={[-8.2, 0.62, -4.15]}>
        <boxGeometry args={[1.9, 0.16, 0.55]} />
        <meshStandardMaterial color="#4a5c6a" roughness={0.7} />
      </mesh>
      <Block
        position={[-8.2, 0.2, -3.05]}
        size={[0.95, 0.38, 0.62]}
        material={m.wood}
      />
      <Block
        position={[-11.6, 0.46, -1.0]}
        size={[0.62, 0.92, 2.35]}
        material={m.trim}
      />
      <Block
        position={[-11.6, 0.81, 0.45]}
        size={[0.58, 1.62, 0.55]}
        material={m.metal}
      />
      <Block
        position={[-6.5, 0.24, 0.15]}
        size={[1.85, 0.48, 1.35]}
        material={m.wood}
      />
      <mesh position={[-6.5, 0.38, 0.15]}>
        <boxGeometry args={[1.7, 0.12, 1.2]} />
        <meshStandardMaterial color="#8a6a4a" />
      </mesh>
      <mesh position={[-6.55, 0.55, -3.55]} material={m.wood} castShadow>
        <boxGeometry args={[0.08, 1.1, 0.08]} />
      </mesh>
      <mesh position={[-6.55, 1.12, -3.55]}>
        <sphereGeometry args={[0.12, 8, 8]} />
        <meshStandardMaterial
          color="#f0e0b0"
          emissive="#d4b56a"
          emissiveIntensity={0.4}
        />
      </mesh>
    </group>
  );
}

function ClosedHouse() {
  const m = getMaterials();
  const { x, z, sx, sz, h } = HOUSE2;
  return (
    <group>
      <Block position={[x, h * 0.5, z]} size={[sx, h, sz]} material={m.stuccoTeal} />
      <Roof x={x} z={z} sx={sx + 0.4} sz={sz + 0.3} y={h} material={m.roof} />
      <mesh position={[x - sx * 0.5 + 0.04, 1.35, z]} material={m.glass}>
        <boxGeometry args={[0.06, 1.15, 1.5]} />
      </mesh>
      <mesh position={[x - sx * 0.5 + 0.05, 1.1, z + 1.4]}>
        <boxGeometry args={[0.08, 2.1, 0.9]} />
        <meshStandardMaterial color="#3e3228" />
      </mesh>
      <Block
        position={[x, 0.04, z - sz * 0.5 - 0.7]}
        size={[2.2, 0.08, 1.4]}
        material={m.sidewalk}
        cast={false}
      />
    </group>
  );
}

function Shop() {
  const m = getMaterials();
  const { x, z, sx, sz, h } = SHOP;
  const sign = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = 128;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#1f2a28";
    ctx.fillRect(0, 0, 512, 128);
    ctx.fillStyle = "#e8dcc4";
    ctx.font = "bold 52px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("BODEGA SOL", 256, 64);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
  return (
    <group>
      <Block position={[x, h * 0.5, z]} size={[sx, h, sz]} material={m.stuccoSand} />
      <mesh position={[x, h + 0.08, z]} material={m.roof} castShadow>
        <boxGeometry args={[sx + 0.3, 0.16, sz + 0.3]} />
      </mesh>
      <mesh position={[x + sx * 0.5 - 0.1, 2.55, z]} rotation={[0, Math.PI / 2, 0.15]} material={m.trim}>
        <boxGeometry args={[sz * 0.85, 0.08, 1.1]} />
      </mesh>
      <mesh position={[x + sx * 0.5 + 0.05, 2.2, z]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[3.4, 0.7]} />
        <meshStandardMaterial map={sign} />
      </mesh>
      <mesh position={[x + sx * 0.5 + 0.02, 1.2, z]} material={m.glass}>
        <boxGeometry args={[0.08, 1.6, 3.2]} />
      </mesh>
    </group>
  );
}

function Fence() {
  const m = getMaterials();
  const posts = [];
  for (let i = 0; i < 8; i++) {
    const x = 6.7 + i * 0.78;
    posts.push(
      <mesh key={"p" + i} position={[x, 0.55, -1.35]} material={m.wood} castShadow>
        <boxGeometry args={[0.08, 1.1, 0.08]} />
      </mesh>,
    );
  }
  return (
    <group>
      {posts}
      <mesh position={[9.4, 0.85, -1.35]} material={m.wood}>
        <boxGeometry args={[5.5, 0.08, 0.05]} />
      </mesh>
      <mesh position={[9.4, 0.45, -1.35]} material={m.wood}>
        <boxGeometry args={[5.5, 0.08, 0.05]} />
      </mesh>
      <mesh position={[6.62, 0.55, 0.7]} material={m.wood} castShadow>
        <boxGeometry args={[0.08, 1.1, 4.1]} />
      </mesh>
      <mesh position={[5.55, 0.52, 4.85]} castShadow>
        <boxGeometry args={[0.85, 1.05, 0.22]} />
        <meshStandardMaterial color="#6a5040" roughness={0.8} />
      </mesh>
      <Block
        position={[12.15, 0.42, -1.4]}
        size={[0.28, 0.85, 6.2]}
        material={m.brick}
      />
    </group>
  );
}

function Dumpster({ x, z }: { x: number; z: number }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 0.55, 0]} castShadow>
        <boxGeometry args={[1.1, 1.1, 0.72]} />
        <meshStandardMaterial color="#4a6a48" roughness={0.7} metalness={0.2} />
      </mesh>
      <mesh position={[0, 1.12, 0]}>
        <boxGeometry args={[1.14, 0.08, 0.76]} />
        <meshStandardMaterial color="#3a5638" />
      </mesh>
    </group>
  );
}

function StopSign() {
  return (
    <group position={[-3.72, 0, -14.05]}>
      <mesh position={[0, 1.1, 0]}>
        <cylinderGeometry args={[0.05, 0.06, 2.2, 8]} />
        <meshStandardMaterial color="#4a4a4a" metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh position={[0, 2.25, 0]} rotation={[0, 0, Math.PI / 8]}>
        <cylinderGeometry args={[0.38, 0.38, 0.06, 8]} />
        <meshStandardMaterial color="#a32020" />
      </mesh>
    </group>
  );
}

function Mailbox() {
  return (
    <group position={[-4.95, 0, -3.55]}>
      <mesh position={[0, 0.45, 0]}>
        <cylinderGeometry args={[0.04, 0.05, 0.9, 8]} />
        <meshStandardMaterial color="#3a3a3a" />
      </mesh>
      <mesh position={[0, 0.95, 0]} castShadow>
        <boxGeometry args={[0.28, 0.22, 0.18]} />
        <meshStandardMaterial color="#6a3a28" />
      </mesh>
    </group>
  );
}

function Hydrant() {
  return (
    <group position={[4.05, 0, -2.85]}>
      <mesh position={[0, 0.32, 0]} castShadow>
        <cylinderGeometry args={[0.12, 0.14, 0.64, 8]} />
        <meshStandardMaterial color="#a33a2a" roughness={0.6} />
      </mesh>
      <mesh position={[0, 0.66, 0]}>
        <sphereGeometry args={[0.12, 8, 8]} />
        <meshStandardMaterial color="#8a3224" />
      </mesh>
    </group>
  );
}

function Boundary() {
  const m = getMaterials();
  const L = 16.25;
  const h = 1.85;
  const t = 0.28;
  return (
    <group>
      <Block position={[0, h * 0.5, L]} size={[33, h, t]} material={m.brick} />
      <Block position={[0, h * 0.5, -L]} size={[33, h, t]} material={m.brick} />
      <Block position={[L, h * 0.5, 0]} size={[t, h, 33]} material={m.brick} />
      <Block position={[-L, h * 0.5, 0]} size={[t, h, 33]} material={m.brick} />
    </group>
  );
}

function Skyline() {
  return (
    <group>
      {SKYLINE.map((b, i) => (
        <mesh key={i} position={[b.x, b.h * 0.5, b.z]} castShadow>
          <boxGeometry args={[b.sx, b.h, b.sz]} />
          <meshStandardMaterial color={b.color} roughness={0.92} />
        </mesh>
      ))}
    </group>
  );
}

export function World() {
  const m = getMaterials();
  return (
    <group>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0, 0]}
        receiveShadow
        material={m.grass}
      >
        <planeGeometry args={[80, 80]} />
      </mesh>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.012, 0]}
        receiveShadow
        material={m.asphalt}
      >
        <planeGeometry args={[6.4, 32.4]} />
      </mesh>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[-3.9, 0.03, 0]}
        receiveShadow
        material={m.sidewalk}
      >
        <planeGeometry args={[1.5, 32.4]} />
      </mesh>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[3.9, 0.03, 0]}
        receiveShadow
        material={m.sidewalk}
      >
        <planeGeometry args={[1.5, 32.4]} />
      </mesh>
      <EnterableHouse />
      <ClosedHouse />
      <Shop />
      <Fence />
      <Palm x={TREES[0].x} z={TREES[0].z} />
      <Palm x={TREES[1].x} z={TREES[1].z} h={4.9} />
      <Palm x={TREES[2].x} z={TREES[2].z} h={4.2} />
      <Leafy x={TREES[3].x} z={TREES[3].z} />
      <Lamp x={-3.95} z={-10.2} />
      <Lamp x={-3.95} z={1.8} />
      <Lamp x={-3.95} z={12.1} />
      <Lamp x={3.95} z={-6.4} />
      <Lamp x={3.95} z={6.6} />
      <Dumpster x={5.35} z={11.45} />
      <Dumpster x={-5.05} z={11.2} />
      <StopSign />
      <Mailbox />
      <Hydrant />
      <Boundary />
      <Skyline />
    </group>
  );
}

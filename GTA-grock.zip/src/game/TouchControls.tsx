import { useRef, type PointerEvent } from "react";
import { CarFront, DoorOpen, Footprints, LogOut } from "lucide-react";
import { input } from "./input";
import { useHud } from "./hudState";

function radial(x: number, y: number, max: number) {
  const m = Math.hypot(x, y);
  if (m < 8) return { x: 0, y: 0 };
  const s = Math.min(1, m / max);
  return { x: (x / m) * s, y: (y / m) * s };
}

export function TouchControls() {
  const hud = useHud();
  const base = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);

  if (!hud.started || hud.paused) return null;

  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    if (pid.current !== null) return;
    pid.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    move(e);
  };
  const move = (e: PointerEvent<HTMLDivElement>) => {
    if (pid.current !== e.pointerId || !base.current || !knob.current) return;
    const r = base.current.getBoundingClientRect();
    const cx = r.left + r.width * 0.5;
    const cy = r.top + r.height * 0.5;
    const v = radial(e.clientX - cx, e.clientY - cy, r.width * 0.38);
    input.stickX = v.x;
    input.stickY = -v.y;
    knob.current.style.transform = `translate(${v.x * 28}px, ${v.y * 28}px)`;
  };
  const onUp = (e: PointerEvent<HTMLDivElement>) => {
    if (pid.current !== e.pointerId) return;
    pid.current = null;
    input.stickX = 0;
    input.stickY = 0;
    if (knob.current) knob.current.style.transform = "translate(0,0)";
  };

  const kind = hud.interactKind;
  const Icon =
    kind === "car-exit" ? LogOut : kind === "car-enter" ? CarFront : DoorOpen;

  return (
    <div className="pointer-events-none absolute inset-0 md:hidden">
      <div
        ref={base}
        className="pointer-events-auto absolute bottom-[max(1.5rem,env(safe-area-inset-bottom))] left-[max(1rem,env(safe-area-inset-left))] size-32 rounded-full border border-border bg-surface/55"
        onPointerDown={onDown}
        onPointerMove={move}
        onPointerUp={onUp}
        onPointerCancel={onUp}
      >
        <div
          ref={knob}
          className="absolute left-1/2 top-1/2 size-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/90"
        />
      </div>

      <div className="pointer-events-auto absolute bottom-[max(1.5rem,env(safe-area-inset-bottom))] right-[max(1rem,env(safe-area-inset-right))] flex flex-col items-end gap-3">
        {kind ? (
          <button
            type="button"
            aria-label={hud.prompt ?? "Action"}
            className="flex size-14 items-center justify-center rounded-full border border-border bg-accent text-accent-fg"
            onPointerDown={(e) => {
              e.preventDefault();
              input.interactHeld = true;
            }}
            onPointerUp={() => {
              input.interactHeld = false;
            }}
            onPointerCancel={() => {
              input.interactHeld = false;
            }}
          >
            <Icon className="size-6" strokeWidth={1.75} />
          </button>
        ) : (
          <div className="size-14" />
        )}
        <button
          type="button"
          aria-label="Courir"
          className="flex size-14 items-center justify-center rounded-full border border-border bg-surface/70 text-fg"
          onPointerDown={(e) => {
            e.preventDefault();
            input.sprintTouch = true;
          }}
          onPointerUp={() => {
            input.sprintTouch = false;
          }}
          onPointerCancel={() => {
            input.sprintTouch = false;
          }}
        >
          <Footprints className="size-6" strokeWidth={1.75} />
        </button>
      </div>
    </div>
  );
}

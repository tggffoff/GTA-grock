import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@react-three/fiber+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CZZ5K_v4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GameApp = (0, import_react.lazy)(() => import("./GameApp-CS-8Ru7j.mjs"));
function Shell() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex h-[100dvh] items-end justify-center bg-bg text-fg sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-10 w-[min(28rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 sm:mb-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
					children: "Quartier libre"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-2 text-4xl tracking-tight",
					children: "ASHWOOD"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Chargement du quartier…"
				})
			]
		})
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {})
	});
}
//#endregion
export { Home as component };

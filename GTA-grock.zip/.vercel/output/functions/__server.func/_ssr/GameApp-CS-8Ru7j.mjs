import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as useFrame, o as require_jsx_runtime, r as useThree, t as Canvas } from "../_libs/@react-three/fiber+[...].mjs";
import { g as SRGBColorSpace, h as RepeatWrapping, i as CanvasTexture, t as Sky, u as MeshStandardMaterial } from "../_libs/@react-three/drei+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as CarFront, i as DoorOpen, n as LogOut, r as Footprints } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/GameApp-CS-8Ru7j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "border border-border bg-surface text-fg hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface-2"
		},
		size: {
			default: "h-11 rounded-md px-5 text-sm",
			lg: "h-12 rounded-lg px-7 text-base",
			icon: "size-11 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"ShiftLeft",
	"ShiftRight",
	"KeyE",
	"KeyF",
	"Space",
	"Escape"
]);
function radial$1(x, y, dz = .16) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	prev = /* @__PURE__ */ new Set();
	lookAccX = 0;
	lookAccY = 0;
	zoomAcc = 0;
	stickX = 0;
	stickY = 0;
	lookStickX = 0;
	lookStickY = 0;
	sprintTouch = false;
	interactHeld = false;
	interactPrev = false;
	dragging = false;
	pointerId = null;
	attach() {
		const down = (e) => {
			if (GAME_CODES.has(e.code)) e.preventDefault();
			this.keys.add(e.code);
		};
		const up = (e) => {
			this.keys.delete(e.code);
		};
		const clear = () => this.keys.clear();
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", clear);
		document.addEventListener("visibilitychange", () => {
			if (document.hidden) clear();
		});
		return () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", clear);
		};
	}
	addLook(dx, dy) {
		this.lookAccX += dx;
		this.lookAccY += dy;
	}
	addZoom(d) {
		this.zoomAcc += d;
	}
	setKeys(codes) {
		this.injected = new Set(codes);
	}
	held() {
		return this.injected ?? this.keys;
	}
	sample(dt) {
		this.pollGamepad();
		const held = this.held();
		let moveX = this.stickX;
		let moveY = this.stickY;
		if (held.has("KeyA") || held.has("ArrowLeft")) moveX -= 1;
		if (held.has("KeyD") || held.has("ArrowRight")) moveX += 1;
		if (held.has("KeyW") || held.has("ArrowUp")) moveY += 1;
		if (held.has("KeyS") || held.has("ArrowDown")) moveY -= 1;
		const ml = Math.hypot(moveX, moveY);
		if (ml > 1) {
			moveX /= ml;
			moveY /= ml;
		}
		let steer = 0;
		if (held.has("KeyA") || held.has("ArrowLeft")) steer += 1;
		if (held.has("KeyD") || held.has("ArrowRight")) steer -= 1;
		steer += -this.stickX;
		steer = Math.max(-1, Math.min(1, steer));
		let throttle = this.stickY;
		if (held.has("KeyW") || held.has("ArrowUp")) throttle += 1;
		if (held.has("KeyS") || held.has("ArrowDown")) throttle -= 1;
		throttle = Math.max(-1, Math.min(1, throttle));
		const sprint = this.sprintTouch || held.has("ShiftLeft") || held.has("ShiftRight");
		const interactKey = held.has("KeyE") && !this.prev.has("KeyE") || held.has("KeyF") && !this.prev.has("KeyF") || held.has("Space") && !this.prev.has("Space");
		const interactTouch = this.interactHeld && !this.interactPrev;
		this.interactPrev = this.interactHeld;
		this.prev = new Set(held);
		const lookX = this.lookAccX + this.lookStickX * 2.4 * dt * 60;
		const lookY = this.lookAccY + this.lookStickY * 2 * dt * 60;
		const zoom = this.zoomAcc;
		this.lookAccX = 0;
		this.lookAccY = 0;
		this.zoomAcc = 0;
		return {
			moveX,
			moveY,
			steer,
			throttle,
			sprint,
			interact: interactKey || interactTouch,
			lookX,
			lookY,
			zoom
		};
	}
	pollGamepad() {
		const pads = navigator.getGamepads?.() ?? [];
		for (const pad of pads) {
			if (!pad || pad.mapping !== "standard") continue;
			const ls = radial$1(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
			this.stickX = ls.x;
			this.stickY = -ls.y;
			const rs = radial$1(pad.axes[2] ?? 0, pad.axes[3] ?? 0, .12);
			this.lookStickX = rs.x;
			this.lookStickY = rs.y;
			if (pad.buttons[0]?.pressed) this.interactHeld = true;
			if (pad.buttons[1]?.pressed) this.sprintTouch = true;
			return;
		}
	}
};
var input = new Input();
var useHud = create(() => ({
	started: false,
	paused: false,
	inVehicle: false,
	prompt: null,
	interactKind: null,
	speedKmh: 0,
	doorOpen: false
}));
function radial(x, y, max) {
	const m = Math.hypot(x, y);
	if (m < 8) return {
		x: 0,
		y: 0
	};
	const s = Math.min(1, m / max);
	return {
		x: x / m * s,
		y: y / m * s
	};
}
function TouchControls() {
	const hud = useHud();
	const base = (0, import_react.useRef)(null);
	const knob = (0, import_react.useRef)(null);
	const pid = (0, import_react.useRef)(null);
	if (!hud.started || hud.paused) return null;
	const onDown = (e) => {
		if (pid.current !== null) return;
		pid.current = e.pointerId;
		e.currentTarget.setPointerCapture(e.pointerId);
		move(e);
	};
	const move = (e) => {
		if (pid.current !== e.pointerId || !base.current || !knob.current) return;
		const r = base.current.getBoundingClientRect();
		const cx = r.left + r.width * .5;
		const cy = r.top + r.height * .5;
		const v = radial(e.clientX - cx, e.clientY - cy, r.width * .38);
		input.stickX = v.x;
		input.stickY = -v.y;
		knob.current.style.transform = `translate(${v.x * 28}px, ${v.y * 28}px)`;
	};
	const onUp = (e) => {
		if (pid.current !== e.pointerId) return;
		pid.current = null;
		input.stickX = 0;
		input.stickY = 0;
		if (knob.current) knob.current.style.transform = "translate(0,0)";
	};
	const kind = hud.interactKind;
	const Icon = kind === "car-exit" ? LogOut : kind === "car-enter" ? CarFront : DoorOpen;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: base,
			className: "pointer-events-auto absolute bottom-[max(1.5rem,env(safe-area-inset-bottom))] left-[max(1rem,env(safe-area-inset-left))] size-32 rounded-full border border-border bg-surface/55",
			onPointerDown: onDown,
			onPointerMove: move,
			onPointerUp: onUp,
			onPointerCancel: onUp,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: knob,
				className: "absolute left-1/2 top-1/2 size-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/90"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto absolute bottom-[max(1.5rem,env(safe-area-inset-bottom))] right-[max(1rem,env(safe-area-inset-right))] flex flex-col items-end gap-3",
			children: [kind ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": hud.prompt ?? "Action",
				className: "flex size-14 items-center justify-center rounded-full border border-border bg-accent text-accent-fg",
				onPointerDown: (e) => {
					e.preventDefault();
					input.interactHeld = true;
				},
				onPointerUp: () => {
					input.interactHeld = false;
				},
				onPointerCancel: () => {
					input.interactHeld = false;
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-6",
					strokeWidth: 1.75
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-14" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Courir",
				className: "flex size-14 items-center justify-center rounded-full border border-border bg-surface/70 text-fg",
				onPointerDown: (e) => {
					e.preventDefault();
					input.sprintTouch = true;
				},
				onPointerUp: () => {
					input.sprintTouch = false;
				},
				onPointerCancel: () => {
					input.sprintTouch = false;
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footprints, {
					className: "size-6",
					strokeWidth: 1.75
				})
			})]
		})]
	});
}
var FIXED_DT = 1 / 60;
var WORLD_LIMIT = 15.7;
var PLAYER_RADIUS = .34;
var PLAYER_HALF_H = .88;
var PLAYER_WALK = 3.35;
var PLAYER_SPRINT = 6.15;
var PLAYER_TURN = 10.5;
var CAR_HALF_L = 1.72;
var CAR_HALF_W = .78;
var CAR_ACCEL = 9.2;
var CAR_REVERSE = 5.4;
var CAR_MAX = 11.5;
var CAR_MAX_REV = 4.2;
var CAR_DRAG = 1.15;
var CAR_TURN = 1.85;
var CAM_DIST_FOOT = 4.15;
var CAM_DIST_CAR = 6.4;
var CAM_LOOK_FOOT = 1.28;
var CAM_LOOK_CAR = 1.15;
var CAM_MIN = 1.15;
var CAM_MAX = 8.5;
var INTERACT_CAR = 2.15;
var INTERACT_DOOR = 1.7;
var PLAYER_SPAWN = {
	x: .2,
	y: PLAYER_HALF_H,
	z: 9.4,
	yaw: 0
};
var CAR_SPAWN = {
	x: 1.62,
	y: 0,
	z: 3.35,
	yaw: 0
};
var HOUSE = {
	x0: -12.55,
	x1: -5.45,
	z0: -5.15,
	z1: 1.25,
	wall: .3,
	height: 2.72,
	doorZ0: -2.72,
	doorZ1: -1.22,
	doorH: 2.18
};
var HOUSE_DOOR = {
	x: HOUSE.x1,
	z: (HOUSE.doorZ0 + HOUSE.doorZ1) * .5
};
function yOverlap(aMin, aMax, bMin, bMax) {
	return aMax > bMin && aMin < bMax;
}
function clamp(v, lo, hi) {
	return v < lo ? lo : v > hi ? hi : v;
}
function shortestAngle(from, to) {
	return Math.atan2(Math.sin(to - from), Math.cos(to - from));
}
function wrapAngle(a) {
	return Math.atan2(Math.sin(a), Math.cos(a));
}
/** Push a vertical cylinder out of an AABB on XZ. Returns penetration push. */
function pushCircleAABB(px, pz, radius, b) {
	const qx = clamp(px, b.minX, b.maxX);
	const qz = clamp(pz, b.minZ, b.maxZ);
	let dx = px - qx;
	let dz = pz - qz;
	const d2 = dx * dx + dz * dz;
	if (d2 > 1e-10) {
		if (d2 >= radius * radius) return null;
		const d = Math.sqrt(d2);
		const pen = radius - d;
		return {
			x: dx / d * pen,
			z: dz / d * pen
		};
	}
	const left = px - b.minX;
	const right = b.maxX - px;
	const south = pz - b.minZ;
	const north = b.maxZ - pz;
	const m = Math.min(left, right, south, north);
	if (m === left) return {
		x: -(left + radius),
		z: 0
	};
	if (m === right) return {
		x: right + radius,
		z: 0
	};
	if (m === south) return {
		x: 0,
		z: -(south + radius)
	};
	return {
		x: 0,
		z: north + radius
	};
}
function pushCircleCircle(px, pz, pr, ox, oz, or) {
	const dx = px - ox;
	const dz = pz - oz;
	const min = pr + or;
	const d2 = dx * dx + dz * dz;
	if (d2 >= min * min) return null;
	if (d2 < 1e-10) return {
		x: min,
		z: 0
	};
	const d = Math.sqrt(d2);
	const pen = min - d;
	return {
		x: dx / d * pen,
		z: dz / d * pen
	};
}
function project(pts, ax, az) {
	let min = Infinity;
	let max = -Infinity;
	for (const [x, z] of pts) {
		const p = x * ax + z * az;
		if (p < min) min = p;
		if (p > max) max = p;
	}
	return {
		min,
		max
	};
}
/**
* 2D SAT: oriented car rectangle vs AABB. MTV on XZ, pointing out of the box.
*/
function pushOBBAgainstAABB(ox, oz, yaw, halfL, halfW, b) {
	const fx = -Math.sin(yaw);
	const fz = -Math.cos(yaw);
	const rx = Math.cos(yaw);
	const rz = -Math.sin(yaw);
	const corners = [
		[ox + fx * halfL + rx * halfW, oz + fz * halfL + rz * halfW],
		[ox + fx * halfL - rx * halfW, oz + fz * halfL - rz * halfW],
		[ox - fx * halfL + rx * halfW, oz - fz * halfL + rz * halfW],
		[ox - fx * halfL - rx * halfW, oz - fz * halfL - rz * halfW]
	];
	const boxPts = [
		[b.minX, b.minZ],
		[b.maxX, b.minZ],
		[b.minX, b.maxZ],
		[b.maxX, b.maxZ]
	];
	const axes = [
		[1, 0],
		[0, 1],
		[fx, fz],
		[rx, rz]
	];
	let minPen = Infinity;
	let nx = 0;
	let nz = 0;
	for (const [ax, az] of axes) {
		const len = Math.hypot(ax, az) || 1;
		const ux = ax / len;
		const uz = az / len;
		const a = project(corners, ux, uz);
		const c = project(boxPts, ux, uz);
		const overlap = Math.min(a.max, c.max) - Math.max(a.min, c.min);
		if (overlap <= 0) return null;
		if (overlap < minPen) {
			minPen = overlap;
			nx = ux;
			nz = uz;
		}
	}
	const boxCx = (b.minX + b.maxX) * .5;
	const boxCz = (b.minZ + b.maxZ) * .5;
	if ((ox - boxCx) * nx + (oz - boxCz) * nz < 0) {
		nx = -nx;
		nz = -nz;
	}
	return {
		x: nx * minPen,
		z: nz * minPen
	};
}
function rayAABB(ox, oy, oz, dx, dy, dz, b, maxT) {
	const invX = dx !== 0 ? 1 / dx : 0x38d7ea4c68000;
	const invY = dy !== 0 ? 1 / dy : 0x38d7ea4c68000;
	const invZ = dz !== 0 ? 1 / dz : 0x38d7ea4c68000;
	let t1 = (b.minX - ox) * invX;
	let t2 = (b.maxX - ox) * invX;
	let tmin = Math.min(t1, t2);
	let tmax = Math.max(t1, t2);
	t1 = (b.minY - oy) * invY;
	t2 = (b.maxY - oy) * invY;
	tmin = Math.max(tmin, Math.min(t1, t2));
	tmax = Math.min(tmax, Math.max(t1, t2));
	t1 = (b.minZ - oz) * invZ;
	t2 = (b.maxZ - oz) * invZ;
	tmin = Math.max(tmin, Math.min(t1, t2));
	tmax = Math.min(tmax, Math.max(t1, t2));
	if (tmax < 0 || tmin > tmax) return maxT + 1;
	const t = tmin >= 0 ? tmin : tmax;
	if (t < 0 || t > maxT) return maxT + 1;
	return t;
}
function rayCylinder(ox, oy, oz, dx, dy, dz, c, maxT) {
	const ex = ox - c.x;
	const ez = oz - c.z;
	const a = dx * dx + dz * dz;
	const b = 2 * (ex * dx + ez * dz);
	const cc = ex * ex + ez * ez - c.r * c.r;
	let tHit = maxT + 1;
	if (a > 1e-10) {
		const disc = b * b - 4 * a * cc;
		if (disc >= 0) {
			const t = (-b - Math.sqrt(disc)) / (2 * a);
			if (t >= 0 && t <= maxT) {
				const y = oy + dy * t;
				if (y >= c.minY && y <= c.maxY) tHit = t;
			}
		}
	}
	return tHit;
}
function box(x, y, z, sx, sy, sz) {
	const hx = sx * .5;
	const hz = sz * .5;
	return {
		minX: x - hx,
		maxX: x + hx,
		minY: y,
		maxY: y + sy,
		minZ: z - hz,
		maxZ: z + hz
	};
}
function wallBox(minX, maxX, minZ, maxZ, minY, maxY) {
	return {
		minX,
		maxX,
		minY,
		maxZ,
		maxX,
		minZ,
		maxY
	};
}
function houseColliders() {
	const { x0, x1, z0, z1, wall, height, doorZ0, doorZ1, doorH } = HOUSE;
	return [
		wallBox(x0, x0 + wall, z0, z1, 0, height),
		wallBox(x0, x1, z0, z0 + wall, 0, height),
		wallBox(x0, x1, z1 - wall, z1, 0, height),
		wallBox(x1 - wall, x1, z0, doorZ0, 0, height),
		wallBox(x1 - wall, x1, doorZ1, z1, 0, height),
		wallBox(x1 - wall, x1, doorZ0, doorZ1, doorH, height),
		wallBox(x0, x1, z0, z1, height - .08, 3.85)
	];
}
function doorCollider() {
	const { x1, wall, doorZ0, doorZ1, doorH } = HOUSE;
	return wallBox(x1 - wall, x1 + .04, doorZ0, doorZ1, 0, doorH);
}
var HOUSE2 = {
	x: 9.35,
	z: 2.55,
	sx: 6.4,
	sz: 5.5,
	h: 2.85
};
var SHOP = {
	x: -9.55,
	z: 8.95,
	sx: 7.5,
	sz: 5.15,
	h: 3.35
};
var TREES = [
	{
		x: 6.45,
		z: -8.2,
		r: .32,
		minY: 0,
		maxY: 5.2
	},
	{
		x: -6.35,
		z: 12.4,
		r: .3,
		minY: 0,
		maxY: 5.2
	},
	{
		x: 11.15,
		z: -6.1,
		r: .28,
		minY: 0,
		maxY: 4.8
	},
	{
		x: -12.2,
		z: 12.55,
		r: .42,
		minY: 0,
		maxY: 4.6
	}
];
var POSTS = [
	{
		x: -3.95,
		z: -10.2,
		r: .1,
		minY: 0,
		maxY: 3.4
	},
	{
		x: -3.95,
		z: 1.8,
		r: .1,
		minY: 0,
		maxY: 3.4
	},
	{
		x: -3.95,
		z: 12.1,
		r: .1,
		minY: 0,
		maxY: 3.4
	},
	{
		x: 3.95,
		z: -6.4,
		r: .1,
		minY: 0,
		maxY: 3.4
	},
	{
		x: 3.95,
		z: 6.6,
		r: .1,
		minY: 0,
		maxY: 3.4
	}
];
function perimeter() {
	const t = 1.15;
	const h = 3.6;
	const L = WORLD_LIMIT + .55;
	return [
		box(0, 0, L, 34, h, t),
		box(0, 0, -L, 34, h, t),
		box(L, 0, 0, t, h, 34),
		box(-L, 0, 0, t, h, 34)
	];
}
function staticBoxes() {
	return [
		...houseColliders(),
		box(HOUSE2.x, 0, HOUSE2.z, HOUSE2.sx, HOUSE2.h, HOUSE2.sz),
		box(SHOP.x, 0, SHOP.z, SHOP.sx, SHOP.h, SHOP.sz),
		box(-8.2, 0, -4.15, 2.05, .72, .85),
		box(-8.2, 0, -3.05, .95, .38, .62),
		box(-11.6, 0, -1, .62, .92, 2.35),
		box(-11.6, 0, .45, .58, 1.62, .55),
		box(-6.5, 0, .15, 1.85, .48, 1.35),
		box(5.35, 0, 11.45, 1.15, 1.15, .78),
		box(-5.05, 0, 11.2, 1.05, 1.12, .72),
		box(12.15, 0, -1.4, .28, .85, 6.2),
		box(9.4, 0, -1.35, 5.6, 1.15, .12),
		box(6.62, 0, .7, .12, 1.15, 4.1),
		box(-4.95, 0, -3.55, .28, 1.05, .22),
		box(4.05, 0, -2.85, .28, .72, .28),
		box(-3.72, 0, -14.05, .18, 2.35, .18),
		box(5.55, 0, 4.85, .85, 1.05, .22),
		...perimeter()
	];
}
var STATIC_BOXES = staticBoxes();
var STATIC_CYL = [...TREES, ...POSTS];
var SKYLINE = [
	{
		x: -22,
		z: 8,
		sx: 6,
		h: 9,
		sz: 5,
		color: "#8a7a6a"
	},
	{
		x: -24,
		z: -6,
		sx: 5,
		h: 7,
		sz: 6,
		color: "#6e7b7a"
	},
	{
		x: 22,
		z: 4,
		sx: 7,
		h: 11,
		sz: 5,
		color: "#7c6d62"
	},
	{
		x: 23,
		z: -10,
		sx: 5,
		h: 6.5,
		sz: 5,
		color: "#8d8474"
	},
	{
		x: -6,
		z: 24,
		sx: 8,
		h: 8,
		sz: 5,
		color: "#6f6860"
	},
	{
		x: 8,
		z: 25,
		sx: 6,
		h: 10,
		sz: 4.5,
		color: "#7a6b5c"
	},
	{
		x: 2,
		z: -24,
		sx: 9,
		h: 7.5,
		sz: 5,
		color: "#65706c"
	},
	{
		x: -12,
		z: -23,
		sx: 5,
		h: 5.5,
		sz: 4,
		color: "#8b735e"
	}
];
var DOOR_COL = doorCollider();
function groundY() {
	return PLAYER_HALF_H;
}
var GameSim = class {
	started = false;
	paused = false;
	time = 0;
	px = PLAYER_SPAWN.x;
	py = PLAYER_SPAWN.y;
	pz = PLAYER_SPAWN.z;
	pvx = 0;
	pvy = 0;
	pvz = 0;
	yaw = PLAYER_SPAWN.yaw;
	walkPhase = 0;
	grounded = true;
	inVehicle = false;
	visiblePlayer = true;
	cx = CAR_SPAWN.x;
	cy = 0;
	cz = CAR_SPAWN.z;
	cyaw = CAR_SPAWN.yaw;
	cspeed = 0;
	wheel = 0;
	steerVis = 0;
	camYaw = 0;
	camPitch = .32;
	camDist = CAM_DIST_FOOT;
	camHitDist = CAM_DIST_FOOT;
	camX = 0;
	camY = 4;
	camZ = 12;
	lookX = 0;
	lookY = 1.4;
	lookZ = 8;
	doorOpen = false;
	doorAngle = 0;
	mountT = 0;
	mountMode = "none";
	prompt = null;
	interactKind = null;
	enterPlayer() {
		this.started = true;
		this.paused = false;
		this.camYaw = this.yaw;
		this.camPitch = .32;
	}
	togglePause() {
		if (!this.started) return;
		this.paused = !this.paused;
	}
	getYaw() {
		return this.inVehicle ? this.cyaw : this.yaw;
	}
	getSpeed() {
		if (this.inVehicle) return Math.abs(this.cspeed);
		return Math.hypot(this.pvx, this.pvz);
	}
	step(dt, inp) {
		const capped = Math.min(Math.max(dt, 0), .1);
		this.time += capped;
		if (!this.started) {
			this.updateCinematic();
			this.syncLook();
			return;
		}
		if (this.paused) {
			this.syncLook();
			return;
		}
		this.camYaw -= inp.lookX * .0052;
		this.camPitch = Math.max(.06, Math.min(1.12, this.camPitch - inp.lookY * .0042));
		if (inp.zoom) this.camDist = Math.max(CAM_MIN, Math.min(CAM_MAX, this.camDist + inp.zoom * .004));
		let acc = capped;
		let steps = 0;
		while (acc >= .016666666666666666 && steps < 6) {
			this.fixed(FIXED_DT, inp);
			acc -= FIXED_DT;
			steps++;
		}
		if (steps === 0) this.fixed(acc, inp);
		this.doorAngle += ((this.doorOpen ? 1.55 : 0) - this.doorAngle) * (1 - Math.exp(-8 * capped));
		this.updateCamera(capped);
	}
	updateCinematic() {
		const t = this.time;
		this.camYaw = .55 + t * .18;
		this.camPitch = .28;
		this.camDist = 11.5;
		this.lookX = .4;
		this.lookY = 1.35;
		this.lookZ = 2.2;
		const fx = -Math.sin(this.camYaw);
		const fz = -Math.cos(this.camYaw);
		this.camX = this.lookX - fx * this.camDist + 1.2;
		this.camY = 4.6;
		this.camZ = this.lookZ - fz * this.camDist;
	}
	fixed(dt, inp) {
		if (this.mountMode !== "none") {
			this.tickMount(dt);
			this.refreshPrompt();
			return;
		}
		this.refreshPrompt();
		if (inp.interact) this.tryInteract();
		if (this.inVehicle) this.drive(dt, inp);
		else this.walk(dt, inp);
		this.constrainWorld();
	}
	walk(dt, inp) {
		const fx = -Math.sin(this.camYaw);
		const fz = -Math.cos(this.camYaw);
		const rx = Math.cos(this.camYaw);
		const rz = -Math.sin(this.camYaw);
		let wx = rx * inp.moveX + fx * inp.moveY;
		let wz = rz * inp.moveX + fz * inp.moveY;
		const wl = Math.hypot(wx, wz);
		const max = inp.sprint ? PLAYER_SPRINT : PLAYER_WALK;
		if (wl > 1e-4) {
			wx /= wl;
			wz /= wl;
			const tyaw = Math.atan2(-wx, -wz);
			this.yaw += shortestAngle(this.yaw, tyaw) * Math.min(1, PLAYER_TURN * dt);
			this.yaw = wrapAngle(this.yaw);
			this.walkPhase += max * dt * 1.9;
		} else this.walkPhase = 0;
		const k = 1 - Math.exp(-14 * dt);
		this.pvx += (wx * max - this.pvx) * k;
		this.pvz += (wz * max - this.pvz) * k;
		this.px += this.pvx * dt;
		this.pz += this.pvz * dt;
		this.resolvePlayer();
		this.pvy -= 28 * dt;
		this.py += this.pvy * dt;
		const g = groundY();
		if (this.py <= g) {
			this.py = g;
			this.pvy = 0;
			this.grounded = true;
		} else this.grounded = false;
		if (this.py > 1.55) {
			this.py = 1.55;
			if (this.pvy > 0) this.pvy = 0;
		}
	}
	drive(dt, inp) {
		const throttle = inp.throttle;
		if (throttle > .05) this.cspeed += CAR_ACCEL * throttle * dt;
		else if (throttle < -.05) {
			if (this.cspeed > .35) this.cspeed -= 16 * -throttle * dt;
			else this.cspeed += -CAR_REVERSE * -throttle * dt;
		}
		this.cspeed *= 1 - CAR_DRAG * dt;
		if (this.cspeed > 11.5) this.cspeed = CAR_MAX;
		if (this.cspeed < -4.2) this.cspeed = -CAR_MAX_REV;
		if (Math.abs(this.cspeed) < .02 && Math.abs(throttle) < .05) this.cspeed = 0;
		const speedFactor = Math.min(1, Math.abs(this.cspeed) / 4.2);
		const reverse = this.cspeed >= 0 ? 1 : -1;
		const steer = inp.steer;
		this.cyaw += steer * CAR_TURN * speedFactor * reverse * dt;
		this.cyaw = wrapAngle(this.cyaw);
		this.steerVis += (steer - this.steerVis) * Math.min(1, 10 * dt);
		this.wheel += this.cspeed * dt * 1.55;
		const fx = -Math.sin(this.cyaw);
		const fz = -Math.cos(this.cyaw);
		const subs = 3;
		const sdt = dt / subs;
		for (let i = 0; i < subs; i++) {
			this.cx += fx * this.cspeed * sdt;
			this.cz += fz * this.cspeed * sdt;
			this.resolveCar();
		}
		this.px = this.cx - Math.cos(this.cyaw) * .32;
		this.pz = this.cz - Math.sin(this.cyaw) * .12;
		this.py = .95;
		this.yaw = this.cyaw;
		this.visiblePlayer = false;
	}
	boxes() {
		const list = STATIC_BOXES.slice();
		if (!this.doorOpen) list.push(DOOR_COL);
		return list;
	}
	resolvePlayer() {
		const ymin = this.py - PLAYER_HALF_H + .08;
		const ymax = this.py + PLAYER_HALF_H - .05;
		const boxes = this.boxes();
		for (let n = 0; n < 3; n++) {
			for (const b of boxes) {
				if (!yOverlap(ymin, ymax, b.minY, b.maxY)) continue;
				const p = pushCircleAABB(this.px, this.pz, PLAYER_RADIUS, b);
				if (p) {
					this.px += p.x;
					this.pz += p.z;
				}
			}
			for (const c of STATIC_CYL) {
				if (!yOverlap(ymin, ymax, c.minY, c.maxY)) continue;
				const p = pushCircleCircle(this.px, this.pz, PLAYER_RADIUS, c.x, c.z, c.r);
				if (p) {
					this.px += p.x;
					this.pz += p.z;
				}
			}
			if (!this.inVehicle) {
				const p = this.pushPlayerFromCar();
				if (p) {
					this.px += p.x;
					this.pz += p.z;
				}
			}
		}
	}
	pushPlayerFromCar() {
		if (!yOverlap(this.py - PLAYER_HALF_H, this.py + PLAYER_HALF_H, 0, 1.35)) return null;
		return pushCircleCircle(this.px, this.pz, PLAYER_RADIUS, this.cx, this.cz, 1.22);
	}
	resolveCar() {
		const boxes = this.boxes();
		for (let n = 0; n < 3; n++) {
			for (const b of boxes) {
				if (!yOverlap(.05, 1.25, b.minY, b.maxY)) continue;
				const p = pushOBBAgainstAABB(this.cx, this.cz, this.cyaw, CAR_HALF_L, CAR_HALF_W, b);
				if (p) {
					this.cx += p.x;
					this.cz += p.z;
					this.cspeed *= .92;
				}
			}
			for (const c of STATIC_CYL) {
				const p = pushCircleCircle(this.cx, this.cz, Math.max(CAR_HALF_W, .95), c.x, c.z, c.r);
				if (p) {
					this.cx += p.x;
					this.cz += p.z;
					this.cspeed *= .88;
				}
			}
		}
	}
	constrainWorld() {
		const lim = WORLD_LIMIT - .4;
		this.px = Math.max(-lim, Math.min(lim, this.px));
		this.pz = Math.max(-lim, Math.min(lim, this.pz));
		this.cx = Math.max(-lim, Math.min(lim, this.cx));
		this.cz = Math.max(-lim, Math.min(lim, this.cz));
		if (this.py < -2) {
			this.px = PLAYER_SPAWN.x;
			this.py = PLAYER_SPAWN.y;
			this.pz = PLAYER_SPAWN.z;
			this.pvx = this.pvz = this.pvy = 0;
			this.inVehicle = false;
			this.visiblePlayer = true;
		}
	}
	carDoorPos() {
		const rx = Math.cos(this.cyaw);
		const rz = -Math.sin(this.cyaw);
		return {
			x: this.cx - rx * 1.25,
			z: this.cz - rz * 1.25
		};
	}
	dist2(ax, az, bx, bz) {
		const dx = ax - bx;
		const dz = az - bz;
		return dx * dx + dz * dz;
	}
	refreshPrompt() {
		if (this.inVehicle || this.mountMode === "enter") {
			this.prompt = "Sortir du véhicule";
			this.interactKind = "car-exit";
			return;
		}
		if (this.mountMode === "exit") {
			this.prompt = null;
			this.interactKind = null;
			return;
		}
		const door = this.carDoorPos();
		const dCar = this.dist2(this.px, this.pz, door.x, door.z);
		const dDoor = this.dist2(this.px, this.pz, HOUSE_DOOR.x, HOUSE_DOOR.z);
		const carOk = dCar < INTERACT_CAR * INTERACT_CAR;
		const doorOk = dDoor < INTERACT_DOOR * INTERACT_DOOR;
		if (carOk && (!doorOk || dCar <= dDoor)) {
			this.prompt = "Entrer dans le véhicule";
			this.interactKind = "car-enter";
			return;
		}
		if (doorOk) {
			this.prompt = this.doorOpen ? "Fermer la porte" : "Ouvrir la porte";
			this.interactKind = "door";
			return;
		}
		this.prompt = null;
		this.interactKind = null;
	}
	tryInteract() {
		if (this.interactKind === "door") {
			this.doorOpen = !this.doorOpen;
			return;
		}
		if (this.interactKind === "car-enter") {
			this.mountMode = "enter";
			this.mountT = 0;
			return;
		}
		if (this.interactKind === "car-exit") {
			this.mountMode = "exit";
			this.mountT = 0;
			this.visiblePlayer = true;
			this.inVehicle = false;
		}
	}
	tickMount(dt) {
		this.mountT += dt / .42;
		const t = Math.min(1, this.mountT);
		if (this.mountMode === "enter") {
			const seatX = this.cx - Math.cos(this.cyaw) * .32;
			const seatZ = this.cz - Math.sin(this.cyaw) * .1;
			const door = this.carDoorPos();
			const mid = t < .55 ? t / .55 : 1;
			const a = t < .55 ? 1 : (t - .55) / .45;
			if (t < .55) {
				this.px += (door.x - this.px) * (1 - Math.pow(1 - mid, 2));
				this.pz += (door.z - this.pz) * (1 - Math.pow(1 - mid, 2));
			} else {
				this.px = door.x + (seatX - door.x) * a;
				this.pz = door.z + (seatZ - door.z) * a;
				this.py = PLAYER_HALF_H + .12 * a;
			}
			this.yaw += shortestAngle(this.yaw, this.cyaw) * .2;
			this.visiblePlayer = t < .92;
			if (t >= 1) {
				this.inVehicle = true;
				this.mountMode = "none";
				this.visiblePlayer = false;
				this.cspeed = 0;
			}
		} else {
			const left = this.exitSpot();
			this.px += (left.x - this.px) * (1 - Math.exp(-10 * dt));
			this.pz += (left.z - this.pz) * (1 - Math.exp(-10 * dt));
			this.py = PLAYER_HALF_H;
			this.visiblePlayer = true;
			this.yaw = this.cyaw;
			if (t >= 1) {
				this.px = left.x;
				this.pz = left.z;
				this.mountMode = "none";
				this.inVehicle = false;
				this.resolvePlayer();
			}
		}
	}
	exitSpot() {
		const rx = Math.cos(this.cyaw);
		const rz = -Math.sin(this.cyaw);
		const candidates = [
			{
				x: this.cx - rx * 1.7,
				z: this.cz - rz * 1.7
			},
			{
				x: this.cx + rx * 1.7,
				z: this.cz + rz * 1.7
			},
			{
				x: this.cx - rx * 1.7 + Math.sin(this.cyaw) * 1.4,
				z: this.cz - rz * 1.7 + Math.cos(this.cyaw) * 1.4
			}
		];
		for (const c of candidates) {
			const saved = {
				x: this.px,
				z: this.pz
			};
			this.px = c.x;
			this.pz = c.z;
			this.resolvePlayer();
			const moved = Math.hypot(this.px - c.x, this.pz - c.z);
			const pos = {
				x: this.px,
				z: this.pz
			};
			this.px = saved.x;
			this.pz = saved.z;
			if (moved < .45) return pos;
		}
		return candidates[0];
	}
	updateCamera(dt) {
		this.syncLook();
		const driving = this.inVehicle || this.mountMode === "enter";
		const desired = driving ? Math.max(this.camDist, CAM_DIST_CAR * .72) : this.camDist || 4.15;
		const fx = -Math.sin(this.camYaw);
		const fz = -Math.cos(this.camYaw);
		const cosP = Math.cos(this.camPitch);
		const sinP = Math.sin(this.camPitch);
		const ox = this.lookX - fx * desired * cosP;
		const oy = this.lookY + desired * sinP + (driving ? .35 : .15);
		const oz = this.lookZ - fz * desired * cosP;
		const dx = ox - this.lookX;
		const dy = oy - this.lookY;
		const dz = oz - this.lookZ;
		const len = Math.hypot(dx, dy, dz) || 1;
		const ux = dx / len;
		const uy = dy / len;
		const uz = dz / len;
		let tHit = len;
		const boxes = this.boxes();
		for (const b of boxes) {
			const t = rayAABB(this.lookX, this.lookY, this.lookZ, ux, uy, uz, b, tHit);
			if (t < tHit) tHit = t;
		}
		for (const c of STATIC_CYL) {
			const t = rayCylinder(this.lookX, this.lookY, this.lookZ, ux, uy, uz, c, tHit);
			if (t < tHit) tHit = t;
		}
		tHit = Math.max(.55, tHit - .22);
		const follow = tHit < this.camHitDist ? 18 : 7;
		this.camHitDist += (tHit - this.camHitDist) * (1 - Math.exp(-follow * dt));
		const tx = this.lookX + ux * this.camHitDist;
		const ty = this.lookY + uy * this.camHitDist;
		const tz = this.lookZ + uz * this.camHitDist;
		const s = 1 - Math.exp(-11 * dt);
		this.camX += (tx - this.camX) * s;
		this.camY += (ty - this.camY) * s;
		this.camZ += (tz - this.camZ) * s;
	}
	syncLook() {
		if (!this.started) return;
		const driving = this.inVehicle;
		this.lookX = driving ? this.cx : this.px;
		this.lookZ = driving ? this.cz : this.pz;
		this.lookY = driving ? CAM_LOOK_CAR : this.py - PLAYER_HALF_H + CAM_LOOK_FOOT;
	}
	hud() {
		return {
			started: this.started,
			paused: this.paused,
			inVehicle: this.inVehicle,
			prompt: this.started ? this.prompt : null,
			interactKind: this.interactKind,
			speedKmh: Math.abs(this.cspeed) * 3.6,
			doorOpen: this.doorOpen
		};
	}
};
var sim = new GameSim();
function Overlay() {
	const hud = useHud();
	const [coarse, setCoarse] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(pointer: coarse)");
		setCoarse(mq.matches);
		const fn = () => setCoarse(mq.matches);
		mq.addEventListener("change", fn);
		return () => mq.removeEventListener("change", fn);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 text-fg",
		children: [
			!hud.started && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-end justify-center bg-bg/55 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-[max(2rem,env(safe-area-inset-bottom))] w-[min(28rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 sm:mb-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
							children: "Quartier libre"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-2 text-4xl tracking-tight text-fg sm:text-5xl",
							children: "ASHWOOD"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "Un pâté de maisons à explorer à pied ou en voiture. Entre dans la maison, ouvre la porte, monte dans le Veldora."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-5 space-y-1.5 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ZQSD / WASD — marcher ou conduire" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Souris / glisser — caméra" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Maj — courir · E — interagir" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-6 w-full",
							size: "lg",
							"data-testid": "start-game",
							onClick: () => sim.enterPlayer(),
							children: "Jouer"
						})
					]
				})
			}),
			hud.started && !hud.paused && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-[max(1rem,env(safe-area-inset-left))] top-[max(1rem,env(safe-area-inset-top))] rounded-md border border-border bg-surface/70 px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm tracking-wide",
						children: "ASHWOOD"
					}), hud.inVehicle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 font-mono text-xs tabular-nums text-muted",
						children: [Math.round(hud.speedKmh), " km/h"]
					})]
				}),
				hud.prompt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-1/2 top-[max(1.25rem,env(safe-area-inset-top))] -translate-x-1/2 rounded-md border border-border bg-surface/80 px-3 py-2 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: hud.prompt
					}), !coarse && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Touche E"
					})]
				}),
				!coarse && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-[max(1rem,env(safe-area-inset-bottom))] left-1/2 hidden -translate-x-1/2 rounded-md border border-border bg-surface/60 px-3 py-1.5 text-xs text-muted md:block",
					children: "WASD · Souris · E interagir · Maj courir"
				})
			] }),
			hud.paused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-[min(22rem,calc(100%-2rem))] rounded-xl border border-border bg-surface px-6 py-7 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Pause"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "La caméra et les déplacements sont figés."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-6 w-full",
							onClick: () => sim.togglePause(),
							children: "Reprendre"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchControls, {})
		]
	});
}
function hash(ix, iy) {
	const n = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453;
	return n - Math.floor(n);
}
function noise(x, y) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const fx = x - ix;
	const fy = y - iy;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	const a = hash(ix, iy);
	const b = hash(ix + 1, iy);
	const c = hash(ix, iy + 1);
	const d = hash(ix + 1, iy + 1);
	return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
function fbm(x, y) {
	return noise(x, y) * .55 + noise(x * 2.1, y * 2.1) * .28 + noise(x * 4.3, y * 4.3) * .17;
}
function canvasTex(size, paint, repeat = 1) {
	const c = document.createElement("canvas");
	c.width = size;
	c.height = size;
	paint(c.getContext("2d"), size);
	const tex = new CanvasTexture(c);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.repeat.set(repeat, repeat);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 4;
	tex.needsUpdate = true;
	return tex;
}
function asphalt(ctx, s) {
	const img = ctx.createImageData(s, s);
	const d = img.data;
	for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
		const n = fbm(x * .07, y * .07);
		const crack = noise(x * .35, y * .04);
		let v = 38 + n * 28;
		if (crack > .78) v -= 16;
		const i = (y * s + x) * 4;
		d[i] = v;
		d[i + 1] = v * .98;
		d[i + 2] = v * .92;
		d[i + 3] = 255;
	}
	ctx.putImageData(img, 0, 0);
	ctx.strokeStyle = "rgba(210, 170, 40, 0.72)";
	ctx.lineWidth = 4;
	ctx.setLineDash([18, 16]);
	ctx.beginPath();
	ctx.moveTo(s * .5, 0);
	ctx.lineTo(s * .5, s);
	ctx.stroke();
}
function concrete(ctx, s) {
	const img = ctx.createImageData(s, s);
	const d = img.data;
	for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
		const v = 148 + fbm(x * .08, y * .08) * 22;
		const i = (y * s + x) * 4;
		d[i] = v;
		d[i + 1] = v - 4;
		d[i + 2] = v - 10;
		d[i + 3] = 255;
	}
	ctx.putImageData(img, 0, 0);
	ctx.strokeStyle = "rgba(90, 90, 86, 0.28)";
	ctx.lineWidth = 2;
	ctx.strokeRect(1, 1, s - 2, s - 2);
}
function grass(ctx, s) {
	const img = ctx.createImageData(s, s);
	const d = img.data;
	for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
		const n = fbm(x * .09, y * .09);
		const p = noise(x * .4, y * .4);
		const i = (y * s + x) * 4;
		d[i] = 62 + n * 40 + p * 12;
		d[i + 1] = 88 + n * 50;
		d[i + 2] = 42 + n * 18;
		d[i + 3] = 255;
	}
	ctx.putImageData(img, 0, 0);
}
function stucco(r, g, b) {
	return (ctx, s) => {
		const img = ctx.createImageData(s, s);
		const d = img.data;
		for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
			const n = fbm(x * .12, y * .12);
			const i = (y * s + x) * 4;
			d[i] = r + n * 22;
			d[i + 1] = g + n * 18;
			d[i + 2] = b + n * 14;
			d[i + 3] = 255;
		}
		ctx.putImageData(img, 0, 0);
	};
}
function roof(ctx, s) {
	ctx.fillStyle = "#6b3a32";
	ctx.fillRect(0, 0, s, s);
	for (let y = 0; y < s; y += 10) {
		const odd = (y / 10 | 0) % 2;
		for (let x = -8; x < s; x += 16) {
			ctx.fillStyle = odd ? "#7a4438" : "#5e322c";
			ctx.fillRect(x, y, 15, 9);
			ctx.strokeStyle = "rgba(40,18,14,0.35)";
			ctx.strokeRect(x, y, 15, 9);
		}
	}
}
function wood(ctx, s) {
	const img = ctx.createImageData(s, s);
	const d = img.data;
	for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
		const n = fbm(x * .02, y * .18);
		const plank = Math.floor(x / 18);
		const i = (y * s + x) * 4;
		d[i] = 118 + n * 30 + plank % 2 * 8;
		d[i + 1] = 86 + n * 22;
		d[i + 2] = 54 + n * 14;
		d[i + 3] = 255;
	}
	ctx.putImageData(img, 0, 0);
	ctx.strokeStyle = "rgba(50,30,18,0.35)";
	for (let x = 18; x < s; x += 18) {
		ctx.beginPath();
		ctx.moveTo(x, 0);
		ctx.lineTo(x, s);
		ctx.stroke();
	}
}
function brick(ctx, s) {
	ctx.fillStyle = "#4a302c";
	ctx.fillRect(0, 0, s, s);
	const bh = 12;
	const bw = 24;
	for (let y = 0, row = 0; y < s; y += bh, row++) {
		const off = row % 2 ? bw * .5 : 0;
		for (let x = -24; x < s; x += bw) {
			const n = hash(x, y);
			ctx.fillStyle = `rgb(${110 + n * 30 | 0},${62 + n * 16 | 0},${48 + n * 10 | 0})`;
			ctx.fillRect(x + off + 1, y + 1, 22, 10);
		}
	}
}
var cache = null;
function std(map, color, extra) {
	return new MeshStandardMaterial({
		map: map ?? void 0,
		color,
		roughness: .86,
		metalness: .04,
		...extra
	});
}
function getMaterials() {
	if (cache) return cache;
	const asphaltMap = canvasTex(256, asphalt, 1);
	asphaltMap.repeat.set(1, 6);
	const conc = canvasTex(256, concrete, 4);
	const gr = canvasTex(256, grass, 10);
	const cream = canvasTex(256, stucco(196, 176, 148), 3);
	const teal = canvasTex(256, stucco(78, 122, 118), 3);
	const sand = canvasTex(256, stucco(186, 154, 108), 3);
	const inside = canvasTex(256, stucco(214, 204, 186), 2);
	const rf = canvasTex(256, roof, 4);
	const wd = canvasTex(256, wood, 2);
	const br = canvasTex(256, brick, 3);
	cache = {
		asphalt: std(asphaltMap, "#8a8a88", { roughness: .92 }),
		sidewalk: std(conc, "#c4c0b6", { roughness: .9 }),
		grass: std(gr, "#7a9a5c", { roughness: .95 }),
		stuccoCream: std(cream, "#ffffff"),
		stuccoTeal: std(teal, "#d5e0dc"),
		stuccoSand: std(sand, "#ffffff"),
		stuccoInside: std(inside, "#ffffff", { roughness: .8 }),
		roof: std(rf, "#ffffff", { roughness: .78 }),
		wood: std(wd, "#ffffff", { roughness: .72 }),
		brick: std(br, "#ffffff", { roughness: .88 }),
		metal: std(null, "#4c4c4c", {
			roughness: .45,
			metalness: .55
		}),
		glass: std(null, "#1c2830", {
			roughness: .18,
			metalness: .35,
			transparent: true,
			opacity: .55
		}),
		foliage: std(null, "#3f6b3a", { roughness: .95 }),
		trunk: std(null, "#5a3d2a", { roughness: .9 }),
		trim: std(null, "#ece3d2", { roughness: .7 })
	};
	return cache;
}
function Block({ position, size, material, cast = true, receive = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		position,
		material,
		castShadow: cast,
		receiveShadow: receive,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: size })
	});
}
function Roof({ x, z, sx, sz, y, material }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			y,
			z
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				0,
				0,
				.38
			],
			position: [
				sx * .18,
				.35,
				0
			],
			material,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				sx * .72,
				.12,
				sz + .3
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				0,
				0,
				-.38
			],
			position: [
				-sx * .18,
				.35,
				0
			],
			material,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				sx * .72,
				.12,
				sz + .3
			] })
		})]
	});
}
function Palm({ x, z, h = 4.6 }) {
	const mats = getMaterials();
	const fronds = (0, import_react.useMemo)(() => {
		return Array.from({ length: 7 }, (_, i) => {
			const a = i / 7 * Math.PI * 2;
			return {
				rot: [
					1.05,
					a,
					0
				],
				pos: [
					Math.sin(a) * .15,
					h,
					Math.cos(a) * .15
				]
			};
		});
	}, [h]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			z
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				0,
				h * .45,
				0
			],
			material: mats.trunk,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.12,
				.22,
				h * .9,
				8
			] })
		}), fronds.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: f.pos,
			rotation: f.rot,
			material: mats.foliage,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("coneGeometry", { args: [
				.85,
				1.7,
				6
			] })
		}, i))]
	});
}
function Leafy({ x, z }) {
	const mats = getMaterials();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			z
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					0,
					1.1,
					0
				],
				material: mats.trunk,
				castShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.18,
					.28,
					2.2,
					8
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					0,
					2.7,
					0
				],
				material: mats.foliage,
				castShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1.35,
					10,
					8
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					.55,
					2.3,
					.3
				],
				material: mats.foliage,
				castShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.7,
					8,
					6
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					-.5,
					2.45,
					-.25
				],
				material: mats.foliage,
				castShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.65,
					8,
					6
				] })
			})
		]
	});
}
function Lamp({ x, z }) {
	const mats = getMaterials();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			z
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					0,
					1.55,
					0
				],
				material: mats.metal,
				castShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.07,
					.09,
					3.1,
					8
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				position: [
					.35,
					3.05,
					0
				],
				material: mats.metal,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.7,
					.06,
					.08
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.62,
					2.92,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.28,
					.16,
					.28
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#efe6c8",
					emissive: "#d8c48a",
					emissiveIntensity: .55
				})]
			})
		]
	});
}
function Door() {
	const ref = (0, import_react.useRef)(null);
	useFrame(() => {
		const g = ref.current;
		if (!g) return;
		g.rotation.y = -sim.doorAngle;
	});
	const hingeZ = HOUSE.doorZ0;
	const leaf = HOUSE.doorZ1 - HOUSE.doorZ0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		position: [
			HOUSE.x1 - .02,
			0,
			hingeZ
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.02,
				HOUSE.doorH * .5,
				leaf * .5
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				HOUSE.doorH,
				leaf - .04
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#5c3d2e",
				roughness: .7
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-.01,
				1.05,
				leaf * .78
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.045,
				8,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#c4b48a",
				metalness: .6,
				roughness: .3
			})]
		})]
	});
}
function EnterableHouse() {
	const m = getMaterials();
	const { x0, x1, z0, z1, wall, height, doorZ0, doorZ1, doorH } = HOUSE;
	const cx = (x0 + x1) * .5;
	const cz = (z0 + z1) * .5;
	const sx = x1 - x0;
	const sz = z1 - z0;
	const innerY = height * .5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x0 + wall * .5,
				innerY,
				cz
			],
			size: [
				wall,
				height,
				sz
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				cx,
				innerY,
				z0 + wall * .5
			],
			size: [
				sx,
				height,
				wall
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				cx,
				innerY,
				z1 - wall * .5
			],
			size: [
				sx,
				height,
				wall
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x1 - wall * .5,
				innerY,
				(z0 + doorZ0) * .5
			],
			size: [
				wall,
				height,
				doorZ0 - z0
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x1 - wall * .5,
				innerY,
				(doorZ1 + z1) * .5
			],
			size: [
				wall,
				height,
				z1 - doorZ1
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x1 - wall * .5,
				(doorH + height) * .5,
				HOUSE_DOOR.z
			],
			size: [
				wall,
				height - doorH,
				doorZ1 - doorZ0
			],
			material: m.stuccoCream
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				cx,
				.02,
				cz
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			material: m.wood,
			receiveShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [sx - wall * 2 + .02, sz - wall * 2 + .02] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				cx,
				height - .04,
				cz
			],
			size: [
				sx - .1,
				.08,
				sz - .1
			],
			material: m.stuccoInside,
			cast: false
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roof, {
			x: cx,
			z: cz,
			sx: sx + .5,
			sz: sz + .35,
			y: height,
			material: m.roof
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x0 + .55,
				height + .9,
				cz
			],
			material: m.brick,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.45,
				.9,
				.45
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				cx,
				1.4,
				z0 + .12
			],
			material: m.glass,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.4,
				1.1,
				.06
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				cx,
				1.4,
				z1 - .12
			],
			material: m.glass,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.4,
				1.1,
				.06
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x1 + .55,
				.06,
				HOUSE_DOOR.z
			],
			size: [
				1.15,
				.1,
				1.7
			],
			material: m.sidewalk,
			cast: false
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Door, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-8.2,
				.36,
				-4.15
			],
			size: [
				2.05,
				.72,
				.85
			],
			material: m.trim
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-8.2,
				.62,
				-4.15
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.9,
				.16,
				.55
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#4a5c6a",
				roughness: .7
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-8.2,
				.2,
				-3.05
			],
			size: [
				.95,
				.38,
				.62
			],
			material: m.wood
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-11.6,
				.46,
				-1
			],
			size: [
				.62,
				.92,
				2.35
			],
			material: m.trim
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-11.6,
				.81,
				.45
			],
			size: [
				.58,
				1.62,
				.55
			],
			material: m.metal
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-6.5,
				.24,
				.15
			],
			size: [
				1.85,
				.48,
				1.35
			],
			material: m.wood
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-6.5,
				.38,
				.15
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.7,
				.12,
				1.2
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#8a6a4a" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				-6.55,
				.55,
				-3.55
			],
			material: m.wood,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				1.1,
				.08
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-6.55,
				1.12,
				-3.55
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.12,
				8,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#f0e0b0",
				emissive: "#d4b56a",
				emissiveIntensity: .4
			})]
		})
	] });
}
function ClosedHouse() {
	const m = getMaterials();
	const { x, z, sx, sz, h } = HOUSE2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x,
				h * .5,
				z
			],
			size: [
				sx,
				h,
				sz
			],
			material: m.stuccoTeal
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roof, {
			x,
			z,
			sx: sx + .4,
			sz: sz + .3,
			y: h,
			material: m.roof
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x - sx * .5 + .04,
				1.35,
				z
			],
			material: m.glass,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.06,
				1.15,
				1.5
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				x - sx * .5 + .05,
				1.1,
				z + 1.4
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				2.1,
				.9
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#3e3228" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x,
				.04,
				z - sz * .5 - .7
			],
			size: [
				2.2,
				.08,
				1.4
			],
			material: m.sidewalk,
			cast: false
		})
	] });
}
function Shop() {
	const m = getMaterials();
	const { x, z, sx, sz, h } = SHOP;
	const sign = (0, import_react.useMemo)(() => {
		const c = document.createElement("canvas");
		c.width = 512;
		c.height = 128;
		const ctx = c.getContext("2d");
		ctx.fillStyle = "#1f2a28";
		ctx.fillRect(0, 0, 512, 128);
		ctx.fillStyle = "#e8dcc4";
		ctx.font = "bold 52px sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText("BODEGA SOL", 256, 64);
		const tex = new CanvasTexture(c);
		tex.colorSpace = SRGBColorSpace;
		return tex;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				x,
				h * .5,
				z
			],
			size: [
				sx,
				h,
				sz
			],
			material: m.stuccoSand
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x,
				h + .08,
				z
			],
			material: m.roof,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				sx + .3,
				.16,
				sz + .3
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x + sx * .5 - .1,
				2.55,
				z
			],
			rotation: [
				0,
				Math.PI / 2,
				.15
			],
			material: m.trim,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				sz * .85,
				.08,
				1.1
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				x + sx * .5 + .05,
				2.2,
				z
			],
			rotation: [
				0,
				Math.PI / 2,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [3.4, .7] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { map: sign })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x + sx * .5 + .02,
				1.2,
				z
			],
			material: m.glass,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				1.6,
				3.2
			] })
		})
	] });
}
function Fence() {
	const m = getMaterials();
	const posts = [];
	for (let i = 0; i < 8; i++) {
		const x = 6.7 + i * .78;
		posts.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				x,
				.55,
				-1.35
			],
			material: m.wood,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				1.1,
				.08
			] })
		}, "p" + i));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		posts,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				9.4,
				.85,
				-1.35
			],
			material: m.wood,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				5.5,
				.08,
				.05
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				9.4,
				.45,
				-1.35
			],
			material: m.wood,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				5.5,
				.08,
				.05
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			position: [
				6.62,
				.55,
				.7
			],
			material: m.wood,
			castShadow: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.08,
				1.1,
				4.1
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				5.55,
				.52,
				4.85
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.85,
				1.05,
				.22
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#6a5040",
				roughness: .8
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				12.15,
				.42,
				-1.4
			],
			size: [
				.28,
				.85,
				6.2
			],
			material: m.brick
		})
	] });
}
function Dumpster({ x, z }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			x,
			0,
			z
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.55,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.1,
				1.1,
				.72
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#4a6a48",
				roughness: .7,
				metalness: .2
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.12,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				1.14,
				.08,
				.76
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#3a5638" })]
		})]
	});
}
function StopSign() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			-3.72,
			0,
			-14.05
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.1,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.05,
				.06,
				2.2,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#4a4a4a",
				metalness: .4,
				roughness: .5
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				2.25,
				0
			],
			rotation: [
				0,
				0,
				Math.PI / 8
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.38,
				.38,
				.06,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#a32020" })]
		})]
	});
}
function Mailbox() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			-4.95,
			0,
			-3.55
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.45,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.04,
				.05,
				.9,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#3a3a3a" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.95,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.28,
				.22,
				.18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#6a3a28" })]
		})]
	});
}
function Hydrant() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			4.05,
			0,
			-2.85
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.32,
				0
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.12,
				.14,
				.64,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#a33a2a",
				roughness: .6
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.66,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.12,
				8,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#8a3224" })]
		})]
	});
}
function Boundary() {
	const m = getMaterials();
	const L = 16.25;
	const h = 1.85;
	const t = .28;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				0,
				h * .5,
				L
			],
			size: [
				33,
				h,
				t
			],
			material: m.brick
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				0,
				h * .5,
				-16.25
			],
			size: [
				33,
				h,
				t
			],
			material: m.brick
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				L,
				h * .5,
				0
			],
			size: [
				t,
				h,
				33
			],
			material: m.brick
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			position: [
				-16.25,
				h * .5,
				0
			],
			size: [
				t,
				h,
				33
			],
			material: m.brick
		})
	] });
}
function Skyline() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: SKYLINE.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			b.x,
			b.h * .5,
			b.z
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			b.sx,
			b.h,
			b.sz
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: b.color,
			roughness: .92
		})]
	}, i)) });
}
function World() {
	const m = getMaterials();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				0,
				0
			],
			receiveShadow: true,
			material: m.grass,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [80, 80] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.012,
				0
			],
			receiveShadow: true,
			material: m.asphalt,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [6.4, 32.4] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				-3.9,
				.03,
				0
			],
			receiveShadow: true,
			material: m.sidewalk,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [1.5, 32.4] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				3.9,
				.03,
				0
			],
			receiveShadow: true,
			material: m.sidewalk,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [1.5, 32.4] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterableHouse, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClosedHouse, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shop, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fence, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palm, {
			x: TREES[0].x,
			z: TREES[0].z
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palm, {
			x: TREES[1].x,
			z: TREES[1].z,
			h: 4.9
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palm, {
			x: TREES[2].x,
			z: TREES[2].z,
			h: 4.2
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leafy, {
			x: TREES[3].x,
			z: TREES[3].z
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lamp, {
			x: -3.95,
			z: -10.2
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lamp, {
			x: -3.95,
			z: 1.8
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lamp, {
			x: -3.95,
			z: 12.1
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lamp, {
			x: 3.95,
			z: -6.4
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lamp, {
			x: 3.95,
			z: 6.6
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumpster, {
			x: 5.35,
			z: 11.45
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumpster, {
			x: -5.05,
			z: 11.2
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StopSign, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mailbox, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hydrant, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boundary, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skyline, {})
	] });
}
function CharacterMesh() {
	const ref = (0, import_react.useRef)(null);
	const lLeg = (0, import_react.useRef)(null);
	const rLeg = (0, import_react.useRef)(null);
	const lArm = (0, import_react.useRef)(null);
	const rArm = (0, import_react.useRef)(null);
	const torso = (0, import_react.useRef)(null);
	useFrame(() => {
		const g = ref.current;
		if (!g) return;
		g.visible = sim.visiblePlayer;
		g.position.set(sim.px, sim.py - PLAYER_HALF_H, sim.pz);
		g.rotation.set(0, sim.yaw + Math.PI, 0);
		const moving = Math.hypot(sim.pvx, sim.pvz) > .35 && !sim.inVehicle;
		const swing = moving ? Math.sin(sim.walkPhase) * .55 : 0;
		const bob = moving ? Math.abs(Math.sin(sim.walkPhase)) * .035 : 0;
		if (lLeg.current) lLeg.current.rotation.x = swing;
		if (rLeg.current) rLeg.current.rotation.x = -swing;
		if (lArm.current) lArm.current.rotation.x = -swing * .7;
		if (rArm.current) rArm.current.rotation.x = swing * .7;
		if (torso.current) torso.current.position.y = .92 + bob;
	});
	const skin = "#c4a07a";
	const shirt = "#6b6a4a";
	const pants = "#3d4a62";
	const shoe = "#2a2a28";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		castShadow: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				ref: torso,
				position: [
					0,
					.92,
					0
				],
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							0,
							.18,
							0
						],
						castShadow: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
							.42,
							.52,
							.26
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
							color: shirt,
							roughness: .82
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							0,
							-.16,
							0
						],
						castShadow: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
							.4,
							.22,
							.24
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
							color: "#5a5940",
							roughness: .85
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							0,
							.52,
							.02
						],
						castShadow: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
							.155,
							10,
							8
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
							color: skin,
							roughness: .7
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							0,
							.6,
							-.01
						],
						castShadow: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
							.16,
							10,
							8
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
							color: "#2b241c",
							roughness: .9
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							.09,
							.54,
							.13
						],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
							.05,
							.03,
							.02
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#1c1a16" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							-.09,
							.54,
							.13
						],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
							.05,
							.03,
							.02
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#1c1a16" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
						ref: lArm,
						position: [
							.28,
							.16,
							0
						],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							position: [
								0,
								-.2,
								0
							],
							castShadow: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
								.1,
								.46,
								.1
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
								color: skin,
								roughness: .72
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							position: [
								0,
								.05,
								0
							],
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
								.12,
								.2,
								.13
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: shirt })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
						ref: rArm,
						position: [
							-.28,
							.16,
							0
						],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							position: [
								0,
								-.2,
								0
							],
							castShadow: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
								.1,
								.46,
								.1
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
								color: skin,
								roughness: .72
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							position: [
								0,
								.05,
								0
							],
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
								.12,
								.2,
								.13
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: shirt })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				ref: lLeg,
				position: [
					.11,
					.52,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.28,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
						.14,
						.52,
						.16
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: pants,
						roughness: .85
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.56,
						.04
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
						.15,
						.1,
						.24
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: shoe })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				ref: rLeg,
				position: [
					-.11,
					.52,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.28,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
						.14,
						.52,
						.16
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: pants,
						roughness: .85
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.56,
						.04
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
						.15,
						.1,
						.24
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: shoe })]
				})]
			})
		]
	});
}
function Wheel({ position, steer = false }) {
	const ref = (0, import_react.useRef)(null);
	useFrame(() => {
		const g = ref.current;
		if (!g) return;
		g.rotation.y = steer ? sim.steerVis * .42 : 0;
		const rim = g.children[0];
		if (rim) rim.rotation.x = sim.wheel;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref,
		position,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				0,
				0,
				Math.PI / 2
			],
			castShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.28,
				.28,
				.18,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#1a1a1a",
				roughness: .8
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				0,
				0,
				Math.PI / 2
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.16,
				.16,
				.2,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#b0aaa2",
				metalness: .45,
				roughness: .4
			})]
		})] })
	});
}
function CarMesh() {
	const ref = (0, import_react.useRef)(null);
	useFrame(() => {
		const g = ref.current;
		if (!g) return;
		g.position.set(sim.cx, 0, sim.cz);
		g.rotation.set(0, sim.cyaw, 0);
	});
	const body = "#c9b79a";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.38,
					0
				],
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.48,
					.42,
					3.22
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#8a3e32",
					roughness: .55,
					metalness: .12
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.62,
					.08
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.42,
					.22,
					3.05
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: body,
					roughness: .48,
					metalness: .15
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.02,
					-.12
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.28,
					.55,
					1.55
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: body,
					roughness: .5
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.05,
					-.08
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.18,
					.42,
					1.35
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#2a3640",
					roughness: .2,
					metalness: .25
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.32,
					-.12
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.3,
					.06,
					1.62
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#6a5a4a",
					roughness: .7
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.52,
					.48,
					-1.52
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.28,
					.16,
					.08
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#f2e6c0",
					emissive: "#f0e0a8",
					emissiveIntensity: .4
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.52,
					.48,
					-1.52
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.28,
					.16,
					.08
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#f2e6c0",
					emissive: "#f0e0a8",
					emissiveIntensity: .4
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.5,
					.48,
					1.58
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.32,
					.14,
					.06
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#8a1e18",
					emissive: "#5a0c08",
					emissiveIntensity: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.5,
					.48,
					1.58
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.32,
					.14,
					.06
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#8a1e18",
					emissive: "#5a0c08",
					emissiveIntensity: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.42,
					-1.55
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.85,
					.12,
					.06
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#2a2a2a" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.74,
					.7,
					.15
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.04,
					.28,
					1.1
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#1c1c1c" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.74,
					.7,
					.15
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.04,
					.28,
					1.1
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#1c1c1c" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wheel, {
				position: [
					.62,
					.28,
					-.95
				],
				steer: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wheel, {
				position: [
					-.62,
					.28,
					-.95
				],
				steer: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wheel, { position: [
				.62,
				.28,
				1.05
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wheel, { position: [
				-.62,
				.28,
				1.05
			] })
		]
	});
}
function Systems() {
	const { camera } = useThree();
	const escPrev = (0, import_react.useRef)(false);
	useFrame((_, delta) => {
		const dt = Math.min(delta, .1);
		const esc = (input.injected ?? input.keys).has("Escape");
		if (esc && !escPrev.current && sim.started) sim.togglePause();
		escPrev.current = esc;
		const inp = input.sample(dt);
		sim.step(dt, inp);
		camera.position.set(sim.camX, sim.camY, sim.camZ);
		camera.lookAt(sim.lookX, sim.lookY, sim.lookZ);
		const h = sim.hud();
		const cur = useHud.getState();
		if (cur.started !== h.started || cur.paused !== h.paused || cur.inVehicle !== h.inVehicle || cur.prompt !== h.prompt || Math.abs(cur.speedKmh - h.speedKmh) > .4) useHud.setState(h);
	});
	return null;
}
function Scene() {
	(0, import_react.useEffect)(() => {
		const w = window;
		w.__controlsTest = {
			getYaw: () => sim.getYaw(),
			getSpeed: () => sim.getSpeed(),
			setKeys: (codes) => {
				input.setKeys(codes);
				if (codes.length > 0) sim.enterPlayer();
			}
		};
		return () => {
			delete w.__controlsTest;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#9bb4c2"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#b7c2bc",
				24,
				62
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#f3e2c4",
			"#3d4a32",
			.82
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .22 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				16,
				18,
				10
			],
			intensity: 1.55,
			color: "#ffd4aa",
			castShadow: true,
			"shadow-mapSize-width": 1024,
			"shadow-mapSize-height": 1024,
			"shadow-camera-near": 2,
			"shadow-camera-far": 55,
			"shadow-camera-left": -20,
			"shadow-camera-right": 20,
			"shadow-camera-top": 20,
			"shadow-camera-bottom": -20,
			"shadow-bias": -35e-5
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sky, {
			sunPosition: [
				16,
				7.5,
				10
			],
			turbidity: 5.5,
			rayleigh: 1.15,
			mieCoefficient: .006,
			mieDirectionalG: .78
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharacterMesh, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarMesh, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Systems, {})
	] });
}
function GameApp() {
	const wrap = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const off = input.attach();
		const el = wrap.current;
		if (!el) return off;
		const lookPid = {
			id: null,
			x: 0,
			y: 0
		};
		const down = (e) => {
			if (!sim.started || sim.paused) return;
			if (e.target.closest("button, [data-touch-ui]")) return;
			if (e.pointerType === "touch") {
				const rect = el.getBoundingClientRect();
				if (e.clientX < rect.left + rect.width * .42) return;
			}
			lookPid.id = e.pointerId;
			lookPid.x = e.clientX;
			lookPid.y = e.clientY;
			el.setPointerCapture(e.pointerId);
		};
		const move = (e) => {
			if (lookPid.id !== e.pointerId) return;
			input.addLook(e.clientX - lookPid.x, e.clientY - lookPid.y);
			lookPid.x = e.clientX;
			lookPid.y = e.clientY;
		};
		const up = (e) => {
			if (lookPid.id === e.pointerId) lookPid.id = null;
		};
		const wheel = (e) => {
			if (!sim.started) return;
			e.preventDefault();
			input.addZoom(e.deltaY);
		};
		el.addEventListener("pointerdown", down);
		el.addEventListener("pointermove", move);
		el.addEventListener("pointerup", up);
		el.addEventListener("pointercancel", up);
		el.addEventListener("wheel", wheel, { passive: false });
		return () => {
			off();
			el.removeEventListener("pointerdown", down);
			el.removeEventListener("pointermove", move);
			el.removeEventListener("pointerup", up);
			el.removeEventListener("pointercancel", up);
			el.removeEventListener("wheel", wheel);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrap,
		className: "relative h-[100dvh] w-full touch-none overflow-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
			shadows: true,
			dpr: [1, 1.5],
			camera: {
				fov: 62,
				near: .12,
				far: 90,
				position: [
					6,
					5,
					14
				]
			},
			gl: {
				antialias: true,
				powerPreference: "high-performance",
				toneMappingExposure: 1.05
			},
			onContextMenu: (e) => e.preventDefault(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {})]
	});
}
//#endregion
export { GameApp as default };

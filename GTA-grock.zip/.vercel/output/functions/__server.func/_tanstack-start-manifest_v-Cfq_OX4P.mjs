//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cfq_OX4P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CnfMPmRP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CnfMPmRP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BJRiRshZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
